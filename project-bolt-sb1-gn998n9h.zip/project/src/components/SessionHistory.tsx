import { useState, useMemo } from 'react';
import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { Session, Category } from '@/lib/supabase';
import { formatDateLong, parseDate, toISODate } from '@/lib/programme';
import { Trash2, Pencil, X, Check, Filter, Calendar } from 'lucide-react';

interface Props {
  sessions: Session[];
  onDelete: (id: string) => Promise<void>;
  onUpdate: (id: string, patch: Partial<Omit<Session, 'id' | 'created_at' | 'user_id'>>) => Promise<void>;
}

export function SessionHistory({ sessions, onDelete, onUpdate }: Props) {
  const [filterCat, setFilterCat] = useState<Category | 'all'>('all');
  const [editing, setEditing] = useState<string | null>(null);
  const [editHours, setEditHours] = useState('');
  const [editNotes, setEditNotes] = useState('');

  const filtered = useMemo(() => {
    if (filterCat === 'all') return sessions;
    return sessions.filter((s) => s.category === filterCat);
  }, [sessions, filterCat]);

  const grouped = useMemo(() => {
    const map: Record<string, Session[]> = {};
    for (const s of filtered) {
      (map[s.date] ??= []).push(s);
    }
    return Object.entries(map).sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  function startEdit(s: Session) {
    setEditing(s.id);
    setEditHours(String(s.hours));
    setEditNotes(s.notes ?? '');
  }

  async function saveEdit(id: string) {
    const h = parseFloat(editHours);
    if (!h || h <= 0) return;
    await onUpdate(id, { hours: h, notes: editNotes.trim() || null });
    setEditing(null);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">Session History</h3>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-slate-400" />
          <select
            value={filterCat}
            onChange={(e) => setFilterCat(e.target.value as Category | 'all')}
            className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs font-medium text-slate-600"
          >
            <option value="all">All Categories</option>
            {CATEGORIES.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
          </select>
        </div>
      </div>

      {grouped.length === 0 ? (
        <div className="rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm">
          <Calendar className="mx-auto mb-2 h-8 w-8 text-slate-300" />
          <p className="text-sm font-medium text-slate-500">No sessions found.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {grouped.map(([date, daySessions]) => (
            <div key={date}>
              <p className="mb-1.5 text-xs font-bold text-slate-400">{formatDateLong(date)}</p>
              <div className="space-y-2">
                {daySessions.map((s) => {
                  const cfg = CATEGORY_MAP[s.category];
                  const Icon = cfg.icon;
                  const isEditing = editing === s.id;
                  return (
                    <div key={s.id} className="group flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
                      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${cfg.bg} ${cfg.text}`}>
                        <Icon className="h-4 w-4" />
                      </span>
                      {isEditing ? (
                        <div className="flex flex-1 items-center gap-2">
                          <input type="number" step="0.25" min="0.25" value={editHours} onChange={(e) => setEditHours(e.target.value)} className="w-20 rounded-lg border border-slate-200 px-2 py-1.5 text-sm" />
                          <input type="text" value={editNotes} onChange={(e) => setEditNotes(e.target.value)} placeholder="Notes" className="flex-1 rounded-lg border border-slate-200 px-2 py-1.5 text-sm" />
                          <button onClick={() => saveEdit(s.id)} className="rounded-lg bg-emerald-500 p-1.5 text-white"><Check className="h-3.5 w-3.5" /></button>
                          <button onClick={() => setEditing(null)} className="rounded-lg bg-slate-100 p-1.5 text-slate-500"><X className="h-3.5 w-3.5" /></button>
                        </div>
                      ) : (
                        <>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-semibold text-slate-800">{cfg.label}</span>
                              {s.status === 'active' && <span className="rounded-full bg-blue-100 px-1.5 py-0.5 text-[10px] font-bold text-blue-600">LIVE</span>}
                            </div>
                            {s.notes && <p className="mt-0.5 truncate text-xs text-slate-400">{s.notes}</p>}
                          </div>
                          <span className={`shrink-0 text-sm font-bold ${cfg.textDark}`}>{Number(s.hours).toFixed(2)}h</span>
                          <button onClick={() => startEdit(s)} className="shrink-0 rounded-lg p-1.5 text-slate-300 opacity-0 hover:bg-slate-100 hover:text-slate-600 group-hover:opacity-100">
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                          <button onClick={() => void onDelete(s.id)} className="shrink-0 rounded-lg p-1.5 text-slate-300 opacity-0 hover:bg-red-50 hover:text-red-500 group-hover:opacity-100">
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
