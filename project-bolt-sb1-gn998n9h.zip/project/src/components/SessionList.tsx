import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { Session } from '@/lib/supabase';
import { formatDateLong } from '@/lib/programme';
import { Trash2 } from 'lucide-react';

interface Props {
  sessions: Session[];
  onDelete: (id: string) => Promise<void>;
}

export function SessionList({ sessions, onDelete }: Props) {
  if (sessions.length === 0) {
    return (
      <div className="rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <p className="text-sm font-medium text-slate-500">No sessions logged yet.</p>
        <p className="mt-1 text-xs text-slate-400">
          Tap "Log Session" to record your first activity.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {sessions.map((s) => {
        const cfg = CATEGORY_MAP[s.category];
        const Icon = cfg.icon;
        return (
          <div
            key={s.id}
            className="group flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3.5 shadow-sm transition-all hover:shadow-md"
          >
            <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${cfg.bg} ${cfg.text}`}>
              <Icon className="h-4 w-4" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-slate-800">{cfg.label}</span>
                <span className="text-xs text-slate-300">·</span>
                <span className="text-xs text-slate-500">{formatDateLong(s.date)}</span>
              </div>
              {s.notes && <p className="mt-0.5 truncate text-xs text-slate-400">{s.notes}</p>}
            </div>
            <span className={`shrink-0 text-sm font-bold ${cfg.textDark}`}>
              {Number(s.hours).toFixed(2)}h
            </span>
            <button
              onClick={() => void onDelete(s.id)}
              className="shrink-0 rounded-lg p-1.5 text-slate-300 opacity-0 transition-opacity hover:bg-red-50 hover:text-red-500 group-hover:opacity-100"
              aria-label="Delete session"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}

export function SessionListLegend() {
  return (
    <div className="flex flex-wrap gap-2">
      {CATEGORIES.map((c) => (
        <span
          key={c.key}
          className={`inline-flex items-center gap-1.5 rounded-full ${c.bgSoft} px-2.5 py-1 text-xs font-medium ${c.text}`}
        >
          <span className={`h-1.5 w-1.5 rounded-full ${c.dot}`} />
          {c.label}
        </span>
      ))}
    </div>
  );
}
