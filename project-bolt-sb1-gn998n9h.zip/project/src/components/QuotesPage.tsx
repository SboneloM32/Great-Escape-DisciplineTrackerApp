import { useState } from 'react';
import { QUOTES, getQuoteOfDay, type AthleteQuote } from '@/lib/quotes';
import { Quote, ChevronLeft, ChevronRight, Shuffle } from 'lucide-react';

export function QuotesPage() {
  const [index, setIndex] = useState(() => QUOTES.indexOf(getQuoteOfDay()));
  const [showAll, setShowAll] = useState(false);
  const quote = QUOTES[index >= 0 ? index : 0];

  function next() {
    setIndex((i) => (i + 1) % QUOTES.length);
  }
  function prev() {
    setIndex((i) => (i - 1 + QUOTES.length) % QUOTES.length);
  }
  function random() {
    let r = Math.floor(Math.random() * QUOTES.length);
    if (r === index) r = (r + 1) % QUOTES.length;
    setIndex(r);
  }

  if (showAll) {
    return (
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-800">All Quotes</h3>
          <button
            onClick={() => setShowAll(false)}
            className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 shadow-sm hover:bg-slate-50"
          >
            Back to Quote of the Day
          </button>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {QUOTES.map((q, i) => (
            <QuoteCard key={i} quote={q} compact />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Quote className="h-5 w-5 text-red-500" />
          <h3 className="text-lg font-bold text-slate-800">Quote of the Day</h3>
        </div>
        <button
          onClick={() => setShowAll(true)}
          className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 shadow-sm hover:bg-slate-50"
        >
          View All
        </button>
      </div>

      <QuoteCard quote={quote} />

      <div className="mt-4 flex items-center justify-center gap-3">
        <button
          onClick={prev}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-sm transition-colors hover:bg-slate-50"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          onClick={random}
          className="flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 shadow-sm transition-colors hover:bg-slate-50"
        >
          <Shuffle className="h-4 w-4" />
          Surprise me
        </button>
        <button
          onClick={next}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-sm transition-colors hover:bg-slate-50"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}

function QuoteCard({ quote, compact = false }: { quote: AthleteQuote; compact?: boolean }) {
  return (
    <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
      <div className="relative h-48 overflow-hidden sm:h-56">
        <img
          src={quote.image}
          alt={quote.alt}
          className="h-full w-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent" />
        <div className="absolute bottom-3 left-4 right-4">
          <p className="text-sm font-bold text-white">{quote.author}</p>
          <p className="text-xs text-slate-300">{quote.title}</p>
        </div>
      </div>
      <div className="p-5">
        <Quote className="h-6 w-6 text-red-200" />
        <p className={`mt-2 font-medium leading-relaxed text-slate-700 ${compact ? 'text-sm' : 'text-base sm:text-lg'}`}>
          {quote.quote}
        </p>
        <div className="mt-3 flex items-center gap-2">
          <span className="h-1 w-8 rounded-full bg-gradient-to-r from-red-500 to-blue-500" />
          <span className="text-xs font-semibold text-slate-500">{quote.author}</span>
        </div>
      </div>
    </div>
  );
}
