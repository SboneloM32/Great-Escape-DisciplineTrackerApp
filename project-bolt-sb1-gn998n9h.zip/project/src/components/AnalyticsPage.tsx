import { useMemo, useState } from 'react';
import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { Session, WeeklyGoal, Category, WeeklyReport } from '@/lib/supabase';
import { weekDateRange, parseDate, TOTAL_WEEKS, formatDateLabel, formatDateLong } from '@/lib/programme';
import { BarChart3, TrendingUp, Calendar, Target, Award, ChevronDown, ChevronUp, FileText, RefreshCw } from 'lucide-react';

interface Props {
  startDate: string | null;
  sessions: Session[];
  goals: WeeklyGoal[];
  reports: WeeklyReport[];
  onGenerateReport: (weekNumber: number) => Promise<void>;
}

export function AnalyticsPage({ startDate, sessions, goals, reports, onGenerateReport }: Props) {
  const [expandedWeek, setExpandedWeek] = useState<number | null>(null);
  const [generating, setGenerating] = useState<number | null>(null);

  const weeklyData = useMemo(() => {
    if (!startDate) return [];
    const result = [];
    for (let w = 1; w <= TOTAL_WEEKS; w++) {
      const range = weekDateRange(startDate, w);
      const ws = parseDate(range.start);
      const we = parseDate(range.end);
      const weekSessions = sessions.filter((s) => {
        const d = parseDate(s.date);
        return d >= ws && d <= we;
      });
      const totalHours = weekSessions.reduce((sum, s) => sum + Number(s.hours), 0);
      const targetHours = goals.filter((g) => g.week_number === w).reduce((sum, g) => sum + g.target_hours, 0);
      const percent = targetHours > 0 ? Math.min((totalHours / targetHours) * 100, 100) : 0;
      const byCat: Record<string, number> = {};
      for (const s of weekSessions) byCat[s.category] = (byCat[s.category] ?? 0) + Number(s.hours);
      const activeDays = new Set(weekSessions.map((s) => s.date)).size;
      const byDay: Record<string, number> = {};
      for (let i = 0; i < 7; i++) {
        const d = new Date(ws);
        d.setDate(ws.getDate() + i);
        const ds = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        byDay[ds] = weekSessions.filter((s) => s.date === ds).reduce((sum, s) => sum + Number(s.hours), 0);
      }
      result.push({ week: w, range, totalHours, targetHours, percent, sessionCount: weekSessions.length, activeDays, byCat, byDay });
    }
    return result;
  }, [startDate, sessions, goals]);

  const maxDayHours = useMemo(() => {
    let max = 1;
    for (const w of weeklyData) for (const v of Object.values(w.byDay)) if (v > max) max = v;
    return max;
  }, [weeklyData]);

  if (!startDate) {
    return (
      <div className="rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <p className="text-sm text-slate-500">Set a start date to see analytics.</p>
      </div>
    );
  }

  const totalLogged = weeklyData.reduce((s, w) => s + w.totalHours, 0);
  const totalTarget = weeklyData.reduce((s, w) => s + w.targetHours, 0);
  const totalSessions = weeklyData.reduce((s, w) => s + w.sessionCount, 0);
  const totalActiveDays = new Set(sessions.map((s) => s.date)).size;

  async function handleGenerate(week: number) {
    setGenerating(week);
    try { await onGenerateReport(week); } finally { setGenerating(null); }
  }

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-extrabold text-slate-800">Weekly Analytics</h2>
        <p className="text-sm text-slate-500">Track your performance across the 5-week journey.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={<BarChart3 className="h-4 w-4" />} label="Total Hours" value={totalLogged.toFixed(1)} color="text-blue-600" bg="bg-blue-50" />
        <StatCard icon={<Target className="h-4 w-4" />} label="Target" value={totalTarget.toFixed(0) + 'h'} color="text-rose-600" bg="bg-rose-50" />
        <StatCard icon={<TrendingUp className="h-4 w-4" />} label="Sessions" value={String(totalSessions)} color="text-emerald-600" bg="bg-emerald-50" />
        <StatCard icon={<Calendar className="h-4 w-4" />} label="Active Days" value={String(totalActiveDays)} color="text-amber-600" bg="bg-amber-50" />
      </div>

      <div className="space-y-3">
        {weeklyData.map((w) => (
          <div key={w.week} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
            <button
              onClick={() => setExpandedWeek(expandedWeek === w.week ? null : w.week)}
              className="flex w-full items-center justify-between p-4"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-rose-600 text-sm font-bold text-white">
                  {w.week}
                </span>
                <div className="text-left">
                  <p className="text-sm font-bold text-slate-800">Week {w.week}</p>
                  <p className="text-xs text-slate-400">{formatDateLabel(w.range.start)} – {formatDateLabel(w.range.end)}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-bold text-slate-800">{w.totalHours.toFixed(1)}h / {w.targetHours}h</p>
                  <div className="mt-1 h-1.5 w-20 overflow-hidden rounded-full bg-slate-100">
                    <div className="h-full rounded-full bg-gradient-to-r from-red-500 to-rose-500" style={{ width: `${w.percent}%` }} />
                  </div>
                </div>
                {expandedWeek === w.week ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
              </div>
            </button>

            {expandedWeek === w.week && (
              <div className="border-t border-slate-100 p-4">
                <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                  <div>
                    <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">Category Breakdown</h4>
                    <div className="space-y-2">
                      {CATEGORIES.map((c) => {
                        const hours = w.byCat[c.key] ?? 0;
                        const target = goals.find((g) => g.week_number === w.week && g.category === c.key)?.target_hours ?? 0;
                        const pct = target > 0 ? Math.min((hours / target) * 100, 100) : 0;
                        const cfg = CATEGORY_MAP[c.key];
                        return (
                          <div key={c.key}>
                            <div className="flex items-center justify-between text-xs">
                              <span className={`font-medium ${cfg.text}`}>{c.label}</span>
                              <span className="text-slate-400">{hours.toFixed(1)}h / {target}h</span>
                            </div>
                            <div className="mt-1 h-2 overflow-hidden rounded-full bg-slate-100">
                              <div className={`h-full rounded-full ${cfg.bar}`} style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">Daily Activity</h4>
                    <div className="flex items-end gap-1.5" style={{ height: 120 }}>
                      {Object.entries(w.byDay).map(([date, hours]) => {
                        const dt = parseDate(date);
                        const h = (hours / maxDayHours) * 100;
                        return (
                          <div key={date} className="flex flex-1 flex-col items-center gap-1">
                            <div className="flex w-full flex-1 items-end">
                              <div
                                className="w-full rounded-t-md bg-gradient-to-t from-blue-400 to-blue-500 transition-all"
                                style={{ height: `${Math.max(h, hours > 0 ? 8 : 0)}%` }}
                                title={`${hours.toFixed(1)}h`}
                              />
                            </div>
                            <span className="text-[10px] font-medium text-slate-400">{['S','M','T','W','T','F','S'][dt.getDay()]}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between rounded-2xl bg-slate-50 p-3">
                  <div className="flex items-center gap-4 text-xs">
                    <span className="text-slate-500"><strong className="text-slate-800">{w.sessionCount}</strong> sessions</span>
                    <span className="text-slate-500"><strong className="text-slate-800">{w.activeDays}</strong> active days</span>
                    <span className="text-slate-500"><strong className="text-slate-800">{w.percent.toFixed(0)}%</strong> complete</span>
                  </div>
                  <button
                    onClick={() => handleGenerate(w.week)}
                    disabled={generating === w.week}
                    className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-xs font-bold text-slate-600 shadow-sm hover:bg-slate-100 disabled:opacity-50"
                  >
                    {generating === w.week ? <RefreshCw className="h-3 w-3 animate-spin" /> : <FileText className="h-3 w-3" />}
                    Generate Report
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {reports.length > 0 && (
        <div>
          <div className="mb-3 flex items-center gap-2">
            <Award className="h-4 w-4 text-amber-500" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">Saved Weekly Reports</h3>
          </div>
          <div className="space-y-2">
            {reports.map((r) => (
              <div key={r.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-bold text-slate-800">Week {r.week_number} Report</p>
                    <p className="text-xs text-slate-400">{formatDateLong(r.generated_at.slice(0, 10))}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-800">{Number(r.total_hours).toFixed(1)}h</p>
                    <p className="text-xs text-slate-400">{Number(r.completion_percent).toFixed(0)}% of target</p>
                  </div>
                </div>
                {r.comparison && (
                  <div className="mt-2 flex gap-3 text-xs">
                    <span className="text-slate-500">vs last week:</span>
                    <span className={Number(r.comparison.delta) >= 0 ? 'text-emerald-600' : 'text-red-500'}>
                      {Number(r.comparison.delta) >= 0 ? '+' : ''}{Number(r.comparison.delta).toFixed(1)}h
                    </span>
                    <span className="text-slate-500">completion: {Number(r.comparison.prev_completion).toFixed(0)}% → {Number(r.completion_percent).toFixed(0)}%</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon, label, value, color, bg }: { icon: React.ReactNode; label: string; value: string; color: string; bg: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
      <div className={`mb-1.5 inline-flex h-7 w-7 items-center justify-center rounded-lg ${bg} ${color}`}>{icon}</div>
      <p className="text-xs font-medium text-slate-400">{label}</p>
      <p className="text-lg font-extrabold text-slate-800">{value}</p>
    </div>
  );
}
