import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { WeekProgress } from '@/hooks/useProgress';
import { formatDateLabel } from '@/lib/programme';
import { CheckCircle2, Circle } from 'lucide-react';

interface Props {
  progress: WeekProgress[];
  currentWeek: number;
  onSelectWeek: (week: number) => void;
  selectedWeek: number;
}

export function WeekTimeline({ progress, currentWeek, onSelectWeek, selectedWeek }: Props) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
      {progress.map((w) => {
        const isCurrent = w.week === currentWeek;
        const isSelected = w.week === selectedWeek;
        const isComplete = w.overallPercent >= 100;
        return (
          <button
            key={w.week}
            onClick={() => onSelectWeek(w.week)}
            className={`group relative overflow-hidden rounded-2xl border p-4 text-left transition-all ${
              isSelected
                ? 'border-red-500 bg-red-50 shadow-md'
                : 'border-slate-200 bg-white shadow-sm hover:border-blue-300 hover:shadow-md'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Week {w.week}
              </span>
              {isCurrent && (
                <span className="rounded-full bg-red-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white">
                  Now
                </span>
              )}
            </div>
            <p className="mt-1 text-xs text-slate-400">
              {formatDateLabel(w.range.start)} – {formatDateLabel(w.range.end)}
            </p>
            <div className="mt-3 flex items-center gap-2">
              {isComplete ? (
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              ) : (
                <Circle className="h-4 w-4 text-slate-300" />
              )}
              <span className="text-lg font-bold text-slate-800">
                {w.overallPercent.toFixed(0)}%
              </span>
            </div>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-500 to-red-500 transition-all duration-500"
                style={{ width: `${w.overallPercent}%` }}
              />
            </div>
            <div className="mt-2 flex gap-1">
              {CATEGORIES.map((c) => {
                const cat = w.categories[c.key];
                return (
                  <div
                    key={c.key}
                    className="h-1 flex-1 overflow-hidden rounded-full bg-slate-100"
                    title={`${c.label}: ${cat.logged.toFixed(1)}h / ${cat.target.toFixed(1)}h`}
                  >
                    <div
                      className={`h-full rounded-full ${CATEGORY_MAP[c.key].bar}`}
                      style={{ width: `${cat.percent}%` }}
                    />
                  </div>
                );
              })}
            </div>
          </button>
        );
      })}
    </div>
  );
}
