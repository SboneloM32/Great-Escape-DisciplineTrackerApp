import { useState } from 'react';
import { todayISO, formatDateLong } from '@/lib/programme';
import { Calendar, Check } from 'lucide-react';

interface Props {
  startDate: string;
  onSave: (date: string) => Promise<void>;
}

export function StartDateEditor({ startDate, onSave }: Props) {
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(startDate || todayISO());
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    try {
      await onSave(date);
      setOpen(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <button
        onClick={() => {
          setDate(startDate || todayISO());
          setOpen(true);
        }}
        className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 shadow-sm transition-colors hover:bg-slate-50"
      >
        <Calendar className="h-4 w-4 text-blue-500" />
        <span className="hidden sm:inline">Started {formatDateLong(startDate)}</span>
        <span className="sm:hidden">Start date</span>
      </button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="relative w-full max-w-sm rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-slate-800">Programme Start Date</h3>
            <p className="mt-1 text-xs text-slate-500">
              Choose the day your 5-week journey begins. All weeks are calculated from here.
            </p>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-4 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100"
            />
            <p className="mt-1 text-xs text-slate-400">{formatDateLong(date)}</p>
            <button
              onClick={handleSave}
              disabled={saving}
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-red-500/30 disabled:opacity-50"
            >
              <Check className="h-4 w-4" />
              {saving ? 'Saving...' : 'Update Start Date'}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
