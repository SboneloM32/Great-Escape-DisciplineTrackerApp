import { CATEGORIES } from '@/lib/categories';
import type { OverallStats } from '@/hooks/useProgress';

export function OverallDonut({ stats }: { stats: OverallStats }) {
  const size = 200;
  const stroke = 18;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const total = stats.totalLogged || 1;

  let offset = 0;
  const segments = CATEGORIES.map((cat) => {
    const value = stats.byCategory[cat.key].logged;
    const fraction = value / total;
    const dash = fraction * circumference;
    const seg = {
      color: cat.accent,
      dash,
      gap: circumference - dash,
      offset: -offset,
    };
    offset += dash;
    return seg;
  });

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center sm:gap-6">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="rgba(0,0,0,0.05)"
            strokeWidth={stroke}
          />
          {segments.map((s, i) => (
            <circle
              key={i}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={s.color}
              strokeWidth={stroke}
              strokeDasharray={`${s.dash} ${s.gap}`}
              strokeDashoffset={s.offset}
              strokeLinecap="round"
              style={{ transition: 'stroke-dasharray 0.6s ease, stroke-dashoffset 0.6s ease' }}
            />
          ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-bold text-slate-800">{stats.totalLogged.toFixed(1)}</span>
          <span className="text-xs font-medium text-slate-400">total hours</span>
        </div>
      </div>
      <div className="flex flex-col gap-2">
        {CATEGORIES.map((cat) => (
          <div key={cat.key} className="flex items-center gap-3">
            <span className="h-3 w-3 rounded-sm" style={{ backgroundColor: cat.accent }} />
            <span className="text-sm font-medium text-slate-600">{cat.label}</span>
            <span className="ml-auto text-sm font-bold text-slate-800">
              {stats.byCategory[cat.key].logged.toFixed(1)}h
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
