import { useMemo } from 'react';
import type { WeekProgress } from '@/hooks/useProgress';

export interface CharacterState {
  level: number;
  size: number;
  label: string;
  hasCrown: boolean;
  hasAura: boolean;
  streak: number;
}

export function computeCharacterState(progress: WeekProgress[]): CharacterState {
  const completedWeeks = progress.filter((w) => w.overallPercent >= 75).length;
  const level = Math.min(completedWeeks + 1, 6);

  let streak = 0;
  for (let i = 0; i < progress.length; i++) {
    if (progress[i].overallPercent >= 75) {
      streak++;
    } else if (progress[i].week < (progress[progress.length - 1]?.week ?? 0)) {
      streak = 0;
    }
  }

  const size = 100 + (level - 1) * 14;
  const hasCrown = streak >= 4;
  const hasAura = level >= 4;

  const labels: Record<number, string> = {
    1: 'Novice',
    2: 'Apprentice',
    3: 'Adept',
    4: 'Warrior',
    5: 'Champion',
    6: 'Legend',
  };

  return {
    level,
    size,
    label: labels[level] ?? 'Novice',
    hasCrown,
    hasAura,
    streak,
  };
}

interface Props {
  state: CharacterState;
}

export function DisciplineCharacter({ state }: Props) {
  const { level, size, label, hasCrown, hasAura, streak } = state;

  const skinTone = '#f4c2a1';
  const hairColor = '#3b2a1a';
  const shirtColor = level >= 5 ? '#dc2626' : level >= 3 ? '#2563eb' : '#3b82f6';
  const pantsColor = '#1e293b';
  const auraColor = level >= 5 ? '#f59e0b' : '#60a5fa';

  const animationClass = useMemo(() => {
    return level >= 2 ? 'animate-character-bob' : '';
  }, [level]);

  return (
    <div className="flex flex-col items-center gap-3">
      <div
        className="relative flex items-end justify-center transition-all duration-700 ease-out"
        style={{ width: size * 1.6, height: size * 1.8 }}
      >
        {hasAura && (
          <div
            className="absolute inset-0 rounded-full opacity-60 blur-2xl"
            style={{ backgroundColor: auraColor, animation: 'pulse-glow 2s ease-in-out infinite' }}
          />
        )}

        <svg
          viewBox="0 0 100 120"
          width={size * 1.4}
          height={size * 1.68}
          className={`relative z-10 ${animationClass}`}
          style={{ overflow: 'visible' }}
        >
          {/* Shadow */}
          <ellipse cx="50" cy="116" rx="22" ry="3.5" fill="rgba(0,0,0,0.12)" />

          {/* Legs */}
          <rect x="40" y="78" width="8" height="28" rx="3" fill={pantsColor} />
          <rect x="52" y="78" width="8" height="28" rx="3" fill={pantsColor} />
          {/* Shoes */}
          <ellipse cx="44" cy="107" rx="6" ry="3" fill="#0f172a" />
          <ellipse cx="56" cy="107" rx="6" ry="3" fill="#0f172a" />

          {/* Body / torso */}
          <path
            d="M 36 52 Q 36 48 40 47 L 60 47 Q 64 48 64 52 L 66 80 Q 66 82 64 82 L 36 82 Q 34 82 34 80 Z"
            fill={shirtColor}
          />
          {/* Shirt accent stripe */}
          <path
            d="M 50 48 L 50 80"
            stroke={level >= 4 ? '#fbbf24' : '#dbeafe'}
            strokeWidth="2"
            strokeLinecap="round"
            opacity="0.8"
          />
          {/* Collar */}
          <path d="M 44 47 Q 50 52 56 47" fill="none" stroke={pantsColor} strokeWidth="1.5" />

          {/* Arms */}
          <g className={level >= 3 ? 'animate-arm-flex' : ''} style={{ transformOrigin: '38px 55px' }}>
            <rect x="28" y="54" width="7" height="22" rx="3.5" fill={shirtColor} />
            <circle cx="31.5" cy="78" r="3.5" fill={skinTone} />
          </g>
          <g className={level >= 3 ? 'animate-arm-flex-r' : ''} style={{ transformOrigin: '62px 55px' }}>
            <rect x="65" y="54" width="7" height="22" rx="3.5" fill={shirtColor} />
            <circle cx="68.5" cy="78" r="3.5" fill={skinTone} />
          </g>

          {/* Neck */}
          <rect x="47" y="42" width="6" height="7" fill={skinTone} />

          {/* Head */}
          <circle cx="50" cy="32" r="13" fill={skinTone} />
          {/* Hair */}
          <path
            d="M 37 30 Q 37 18 50 17 Q 63 18 63 30 Q 60 24 50 24 Q 40 24 37 30 Z"
            fill={hairColor}
          />
          {/* Eyes */}
          <circle cx="45" cy="32" r="1.4" fill="#1e293b" />
          <circle cx="55" cy="32" r="1.4" fill="#1e293b" />
          {/* Smile */}
          <path
            d="M 45 37 Q 50 40 55 37"
            fill="none"
            stroke="#9a4a2a"
            strokeWidth="1.2"
            strokeLinecap="round"
          />

          {/* Level badge on chest */}
          <circle
            cx="50"
            cy="62"
            r="6"
            fill="rgba(255,255,255,0.92)"
            stroke={level >= 4 ? '#f59e0b' : '#3b82f6'}
            strokeWidth="1.5"
          />
          <text
            x="50"
            y="65"
            textAnchor="middle"
            fontSize="7"
            fontWeight="bold"
            fill={level >= 4 ? '#b45309' : '#1d4ed8'}
          >
            {level}
          </text>

          {/* Crown for 4+ week streak */}
          {hasCrown && (
            <g className="animate-crown-float" style={{ transformOrigin: '50px 14px' }}>
              <path
                d="M 38 16 L 42 8 L 46 13 L 50 6 L 54 13 L 58 8 L 62 16 L 60 20 L 40 20 Z"
                fill="#fbbf24"
                stroke="#d97706"
                strokeWidth="0.8"
                strokeLinejoin="round"
              />
              <circle cx="50" cy="11" r="1.2" fill="#ef4444" />
              <circle cx="43" cy="13" r="0.9" fill="#3b82f6" />
              <circle cx="57" cy="13" r="0.9" fill="#10b981" />
            </g>
          )}
        </svg>
      </div>

      {/* Level label */}
      <div className="flex flex-col items-center gap-1">
        <div className="flex items-center gap-1.5">
          <span className="inline-flex items-center gap-1 rounded-full bg-red-500 px-2.5 py-1 text-xs font-bold text-white shadow-sm">
            LV {level}
          </span>
          <span className="text-sm font-semibold text-slate-700">{label}</span>
        </div>
        {streak > 0 && (
          <span className="text-xs font-medium text-orange-500">
            {streak}-week streak
            {hasCrown ? ' — Crown earned!' : ''}
          </span>
        )}
      </div>
    </div>
  );
}
