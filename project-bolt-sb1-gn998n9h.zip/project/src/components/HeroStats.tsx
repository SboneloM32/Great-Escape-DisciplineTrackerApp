import { CATEGORIES } from '@/lib/categories';
import type { OverallStats } from '@/hooks/useProgress';
import { TrendingUp, Target, Flame } from 'lucide-react';

interface Props {
  stats: OverallStats;
  currentWeek: number;
}

export function HeroStats({ stats, currentWeek }: Props) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      <StatCard
        icon={<Flame className="h-4 w-4" />}
        label="Current Week"
        value={currentWeek > 0 ? `Week ${currentWeek}` : 'Not started'}
        accent="text-amber-600"
        bg="bg-amber-50"
      />
      <StatCard
        icon={<TrendingUp className="h-4 w-4" />}
        label="Hours Logged"
        value={`${stats.totalLogged.toFixed(1)}h`}
        accent="text-emerald-600"
        bg="bg-emerald-50"
      />
      <StatCard
        icon={<Target className="h-4 w-4" />}
        label="Total Target"
        value={`${stats.totalTarget.toFixed(1)}h`}
        accent="text-blue-600"
        bg="bg-blue-50"
      />
      <StatCard
        icon={<TrendingUp className="h-4 w-4" />}
        label="Overall Progress"
        value={`${stats.percent.toFixed(0)}%`}
        accent="text-rose-600"
        bg="bg-rose-50"
      />
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  accent,
  bg,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent: string;
  bg: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-sm transition-shadow hover:shadow-md">
      <div className="flex items-center gap-2">
        <span className={`flex h-7 w-7 items-center justify-center rounded-lg ${bg} ${accent}`}>
          {icon}
        </span>
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">{label}</span>
      </div>
      <p className="mt-2 text-xl font-bold text-slate-800">{value}</p>
    </div>
  );
}

export function CategoryLegend() {
  return (
    <div className="flex flex-wrap gap-3">
      {CATEGORIES.map((c) => (
        <div key={c.key} className="flex items-center gap-2">
          <span className={`h-2.5 w-2.5 rounded-full ${c.dot}`} />
          <span className="text-sm font-medium text-slate-600">{c.label}</span>
        </div>
      ))}
    </div>
  );
}
