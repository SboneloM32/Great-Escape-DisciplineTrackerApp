import { useState } from 'react';
import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { Category, WeeklyGoal } from '@/lib/supabase';
import { TOTAL_WEEKS, weekDateRange, formatDateLabel } from '@/lib/programme';
import { Save, X } from 'lucide-react';

interface Props {
  startDate: string;
  goals: WeeklyGoal[];
  onSave: (week: number, category: Category, hours: number) => Promise<void>;
  open: boolean;
  onClose: () => void;
}

export function GoalsEditor({ startDate, goals, onSave, open, onClose }: Props) {
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  function getKey(week: number, cat: Category) {
    return `${week}-${cat}`;
  }

  function getValue(week: number, cat: Category): string {
    const key = getKey(week, cat);
    if (key in drafts) return drafts[key];
    const existing = goals.find((g) => g.week_number === week && g.category === cat);
    return existing ? String(existing.target_hours) : '0';
  }

  function setValue(week: number, cat: Category, val: string) {
    setDrafts((d) => ({ ...d, [getKey(week, cat)]: val }));
  }

  async function handleSave() {
    setSaving(true);
    setError(null);
    try {
      for (let w = 1; w <= TOTAL_WEEKS; w++) {
        for (const cat of CATEGORIES) {
          const key = getKey(w, cat.key);
          if (key in drafts) {
            const h = parseFloat(drafts[key]);
            if (!Number.isNaN(h) && h >= 0) {
              await onSave(w, cat.key, h);
            }
          }
        }
      }
      setDrafts({});
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save goals');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative max-h-[85vh] w-full max-w-3xl overflow-y-auto rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl scrollbar-thin">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-800">Weekly Targets</h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Set the hours you aim for in each category, per week.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-5 space-y-3">
          {Array.from({ length: TOTAL_WEEKS }, (_, i) => i + 1).map((w) => {
            const range = weekDateRange(startDate, w);
            return (
              <div key={w} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-800">Week {w}</span>
                  <span className="text-xs text-slate-400">
                    {formatDateLabel(range.start)} – {formatDateLabel(range.end)}
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {CATEGORIES.map((cat) => {
                    const cfg = CATEGORY_MAP[cat.key];
                    const Icon = cfg.icon;
                    return (
                      <div key={cat.key} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
                        <Icon className={`h-4 w-4 shrink-0 ${cfg.text}`} />
                        <input
                          type="number"
                          min="0"
                          step="0.5"
                          value={getValue(w, cat.key)}
                          onChange={(e) => setValue(w, cat.key, e.target.value)}
                          className="w-full bg-transparent text-sm font-medium text-slate-800 outline-none"
                        />
                        <span className="text-xs text-slate-400">h</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {error && <p className="mt-4 text-sm font-medium text-red-600">{error}</p>}

        <div className="mt-5 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-red-500/30 disabled:opacity-50"
          >
            <Save className="h-4 w-4" />
            {saving ? 'Saving...' : 'Save Targets'}
          </button>
        </div>
      </div>
    </div>
  );
}
