import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { WeekProgress } from '@/hooks/useProgress';
import { formatDateLabel } from '@/lib/programme';

interface Props {
  week: WeekProgress;
}

export function WeekDetail({ week }: Props) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="text-lg font-bold text-slate-800">Week {week.week} Breakdown</h3>
        <span className="text-sm font-medium text-slate-500">
          {formatDateLabel(week.range.start)} – {formatDateLabel(week.range.end)}
        </span>
      </div>
      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {CATEGORIES.map((cat) => {
          const data = week.categories[cat.key];
          const cfg = CATEGORY_MAP[cat.key];
          const Icon = cfg.icon;
          return (
            <div
              key={cat.key}
              className={`rounded-2xl border border-slate-200 ${cfg.bgSoft} p-4`}
            >
              <div className="flex items-center gap-3">
                <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${cfg.bg} ${cfg.text}`}>
                  <Icon className="h-4 w-4" />
                </span>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-800">{cat.label}</p>
                  <p className="text-xs text-slate-500">
                    {data.logged.toFixed(1)}h of {data.target.toFixed(1)}h
                  </p>
                </div>
                <span className={`text-sm font-bold ${cfg.textDark}`}>
                  {data.percent.toFixed(0)}%
                </span>
              </div>
              <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                <div
                  className={`h-full rounded-full ${cfg.bar} transition-all duration-500`}
                  style={{ width: `${data.percent}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-4 flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3">
        <span className="text-sm font-medium text-slate-600">Week total</span>
        <span className="text-sm font-bold text-slate-800">
          {week.totalLogged.toFixed(1)}h / {week.totalTarget.toFixed(1)}h ({week.overallPercent.toFixed(0)}%)
        </span>
      </div>
    </div>
  );
}
