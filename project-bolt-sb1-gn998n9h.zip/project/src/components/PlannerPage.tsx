import { useState, useMemo } from 'react';
import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { Category, PlannerItem, Routine } from '@/lib/supabase';
import { todayISO, toISODate, parseDate, formatDateLong } from '@/lib/programme';
import { Plus, Trash2, Check, Repeat, CalendarDays, X, Clock } from 'lucide-react';

interface Props {
  plannerItems: PlannerItem[];
  routines: Routine[];
  onAdd: (item: Omit<PlannerItem, 'id' | 'created_at' | 'user_id'>) => Promise<void>;
  onUpdate: (id: string, patch: Partial<Omit<PlannerItem, 'id' | 'created_at' | 'user_id'>>) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  onAddRoutine: (routine: Omit<Routine, 'id' | 'created_at' | 'user_id'>) => Promise<void>;
  onDeleteRoutine: (id: string) => Promise<void>;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const FULL_DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export function PlannerPage({ plannerItems, routines, onAdd, onUpdate, onDelete, onAddRoutine, onDeleteRoutine }: Props) {
  const [selectedDate, setSelectedDate] = useState(todayISO());
  const [showAdd, setShowAdd] = useState(false);
  const [showRoutine, setShowRoutine] = useState(false);
  const [view, setView] = useState<'day' | 'week'>('day');

  const weekDays = useMemo(() => {
    const d = parseDate(selectedDate);
    const dayOfWeek = d.getDay();
    const sunday = new Date(d);
    sunday.setDate(d.getDate() - dayOfWeek);
    return Array.from({ length: 7 }, (_, i) => {
      const dt = new Date(sunday);
      dt.setDate(sunday.getDate() + i);
      return toISODate(dt);
    });
  }, [selectedDate]);

  const visibleDates = view === 'day' ? [selectedDate] : weekDays;

  const itemsByDate = useMemo(() => {
    const map: Record<string, PlannerItem[]> = {};
    for (const d of visibleDates) {
      map[d] = plannerItems
        .filter((p) => p.date === d)
        .sort((a, b) => a.start_time.localeCompare(b.start_time));
    }
    return map;
  }, [plannerItems, visibleDates]);

  const routinesForDay = (dateStr: string) => {
    const dow = parseDate(dateStr).getDay();
    return routines.filter((r) => r.day_of_week === dow && r.active);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-800">Daily Planner</h2>
          <p className="text-sm text-slate-500">Schedule activities and manage recurring routines.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowRoutine(true)}
            className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-600 shadow-sm hover:bg-slate-50"
          >
            <Repeat className="h-4 w-4 text-blue-500" /> Routine
          </button>
          <button
            onClick={() => setShowAdd(true)}
            className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-red-500 to-rose-600 px-4 py-2 text-sm font-bold text-white shadow-lg shadow-red-500/30 hover:scale-[1.02] active:scale-95"
          >
            <Plus className="h-4 w-4" /> Add Activity
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="flex rounded-xl bg-slate-100 p-1">
          <button onClick={() => setView('day')} className={`rounded-lg px-4 py-1.5 text-sm font-bold ${view === 'day' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}`}>Day</button>
          <button onClick={() => setView('week')} className={`rounded-lg px-4 py-1.5 text-sm font-bold ${view === 'week' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}`}>Week</button>
        </div>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus:border-red-400"
        />
      </div>

      {view === 'week' && (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
          {weekDays.map((d) => {
            const dt = parseDate(d);
            const count = itemsByDate[d]?.length ?? 0;
            const isToday = d === todayISO();
            return (
              <button
                key={d}
                onClick={() => { setSelectedDate(d); setView('day'); }}
                className={`rounded-2xl border p-3 text-left transition-all ${isToday ? 'border-red-300 bg-red-50' : 'border-slate-200 bg-white hover:bg-slate-50'}`}
              >
                <p className="text-xs font-bold text-slate-400">{DAYS[dt.getDay()]}</p>
                <p className="text-lg font-extrabold text-slate-800">{dt.getDate()}</p>
                <p className="text-xs text-slate-400">{count} planned</p>
              </button>
            );
          })}
        </div>
      )}

      <div className="space-y-4">
        {visibleDates.map((d) => (
          <div key={d}>
            <div className="mb-2 flex items-center gap-2">
              <CalendarDays className="h-4 w-4 text-slate-400" />
              <h3 className="text-sm font-bold text-slate-700">{formatDateLong(d)}</h3>
            </div>
            <div className="space-y-2">
              {routinesForDay(d).map((r) => {
                const cfg = CATEGORY_MAP[r.category];
                const Icon = cfg.icon;
                return (
                  <div key={r.id} className="flex items-center gap-3 rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-3">
                    <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${cfg.bg} ${cfg.text}`}>
                      <Icon className="h-4 w-4" />
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-slate-700">{r.title ?? cfg.label}</p>
                      <p className="text-xs text-slate-400">
                        <Clock className="mr-1 inline h-3 w-3" />
                        {r.start_time.slice(0, 5)} · {r.duration_minutes}min · Weekly
                      </p>
                    </div>
                    <button onClick={() => void onDeleteRoutine(r.id)} className="rounded-lg p-1.5 text-slate-300 hover:bg-red-50 hover:text-red-500">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                );
              })}
              {(itemsByDate[d] ?? []).map((item) => {
                const cfg = CATEGORY_MAP[item.category];
                const Icon = cfg.icon;
                return (
                  <div key={item.id} className={`flex items-center gap-3 rounded-2xl border p-3 transition-all ${item.completed ? 'border-emerald-200 bg-emerald-50' : 'border-slate-200 bg-white shadow-sm'}`}>
                    <button
                      onClick={() => void onUpdate(item.id, { completed: !item.completed })}
                      className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${item.completed ? 'bg-emerald-500 text-white' : `${cfg.bg} ${cfg.text}`}`}
                    >
                      {item.completed ? <Check className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
                    </button>
                    <div className="flex-1">
                      <p className={`text-sm font-semibold ${item.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                        {item.title ?? cfg.label}
                      </p>
                      <p className="text-xs text-slate-400">
                        {item.start_time.slice(0, 5)} · {item.duration_minutes}min
                      </p>
                      {item.notes && <p className="mt-0.5 truncate text-xs text-slate-400">{item.notes}</p>}
                    </div>
                    <button onClick={() => void onDelete(item.id)} className="rounded-lg p-1.5 text-slate-300 hover:bg-red-50 hover:text-red-500">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                );
              })}
              {routinesForDay(d).length === 0 && (itemsByDate[d] ?? []).length === 0 && (
                <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center">
                  <p className="text-sm text-slate-400">Nothing planned. Add an activity or set up a routine.</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {showAdd && (
        <AddPlannerModal
          date={selectedDate}
          onClose={() => setShowAdd(false)}
          onAdd={async (item) => { await onAdd(item); setShowAdd(false); }}
        />
      )}
      {showRoutine && (
        <AddRoutineModal
          onClose={() => setShowRoutine(false)}
          onAdd={async (r) => { await onAddRoutine(r); setShowRoutine(false); }}
        />
      )}
    </div>
  );
}

function AddPlannerModal({ date, onClose, onAdd }: { date: string; onClose: () => void; onAdd: (item: Omit<PlannerItem, 'id' | 'created_at' | 'user_id'>) => Promise<void> }) {
  const [itemDate, setItemDate] = useState(date);
  const [startTime, setStartTime] = useState('09:00');
  const [duration, setDuration] = useState('60');
  const [category, setCategory] = useState<Category>('studying');
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await onAdd({
        date: itemDate, start_time: startTime, duration_minutes: parseInt(duration) || 60,
        category, title: title.trim() || null, notes: notes.trim() || null, completed: false,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add activity');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-800">Schedule Activity</h3>
          <button onClick={onClose} className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100"><X className="h-4 w-4" /></button>
        </div>
        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Date</label>
              <input type="date" value={itemDate} onChange={(e) => setItemDate(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Start</label>
              <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Duration (min)</label>
            <input type="number" min="5" step="5" value={duration} onChange={(e) => setDuration(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Category</label>
            <div className="mt-1.5 grid grid-cols-2 gap-2">
              {CATEGORIES.map((c) => {
                const Icon = c.icon;
                return (
                  <button type="button" key={c.key} onClick={() => setCategory(c.key)}
                    className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-sm font-medium ${category === c.key ? `${CATEGORY_MAP[c.key].bg} ${CATEGORY_MAP[c.key].textDark} border-transparent` : 'border-slate-200 bg-white text-slate-500'}`}>
                    <Icon className="h-4 w-4" /> {c.label}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Title (optional)</label>
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Morning study session" className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
          </div>
          {error && <p className="text-sm font-medium text-red-600">{error}</p>}
          <button type="submit" disabled={saving} className="w-full rounded-xl bg-gradient-to-r from-red-500 to-rose-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-red-500/30 disabled:opacity-50">
            {saving ? 'Saving...' : 'Add to Planner'}
          </button>
        </form>
      </div>
    </div>
  );
}

function AddRoutineModal({ onClose, onAdd }: { onClose: () => void; onAdd: (r: Omit<Routine, 'id' | 'created_at' | 'user_id'>) => Promise<void> }) {
  const [dayOfWeek, setDayOfWeek] = useState(1);
  const [startTime, setStartTime] = useState('08:00');
  const [duration, setDuration] = useState('60');
  const [category, setCategory] = useState<Category>('studying');
  const [title, setTitle] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await onAdd({
        day_of_week: dayOfWeek, start_time: startTime, duration_minutes: parseInt(duration) || 60,
        category, title: title.trim() || null, active: true,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add routine');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-800">New Routine</h3>
          <button onClick={onClose} className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100"><X className="h-4 w-4" /></button>
        </div>
        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Day</label>
            <select value={dayOfWeek} onChange={(e) => setDayOfWeek(parseInt(e.target.value))} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400">
              {FULL_DAYS.map((d, i) => <option key={i} value={i}>{d}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Start</label>
              <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Duration (min)</label>
              <input type="number" min="5" step="5" value={duration} onChange={(e) => setDuration(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Category</label>
            <div className="mt-1.5 grid grid-cols-2 gap-2">
              {CATEGORIES.map((c) => {
                const Icon = c.icon;
                return (
                  <button type="button" key={c.key} onClick={() => setCategory(c.key)}
                    className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-sm font-medium ${category === c.key ? `${CATEGORY_MAP[c.key].bg} ${CATEGORY_MAP[c.key].textDark} border-transparent` : 'border-slate-200 bg-white text-slate-500'}`}>
                    <Icon className="h-4 w-4" /> {c.label}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Title (optional)</label>
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Evening workout" className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
          </div>
          {error && <p className="text-sm font-medium text-red-600">{error}</p>}
          <button type="submit" disabled={saving} className="w-full rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-blue-500/30 disabled:opacity-50">
            {saving ? 'Saving...' : 'Create Routine'}
          </button>
        </form>
      </div>
    </div>
  );
}
