import { useState } from 'react';
import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { Category, Session } from '@/lib/supabase';
import { todayISO, formatDateLong } from '@/lib/programme';
import { Plus, X } from 'lucide-react';

interface Props {
  onAdd: (session: Omit<Session, 'id' | 'created_at' | 'user_id'>) => Promise<void>;
}

export function LogSessionModal({ onAdd }: Props) {
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(todayISO());
  const [category, setCategory] = useState<Category>('studying');
  const [hours, setHours] = useState('1');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const h = parseFloat(hours);
    if (!h || h <= 0) {
      setError('Enter a valid number of hours.');
      return;
    }
    setSubmitting(true);
    try {
      await onAdd({ date, category, hours: h, notes: notes.trim() || null, status: 'completed', started_at: null, paused_at: null, elapsed_seconds: 0, planner_item_id: null });
      setOpen(false);
      setHours('1');
      setNotes('');
      setDate(todayISO());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to log session');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-red-500 to-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-red-500/30 transition-transform hover:scale-[1.02] active:scale-95"
      >
        <Plus className="h-4 w-4" />
        Log Session
      </button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
          <div className="relative w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800">Log a Session</h3>
              <button
                onClick={() => setOpen(false)}
                className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100"
                />
                <p className="mt-1 text-xs text-slate-400">{formatDateLong(date)}</p>
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Category
                </label>
                <div className="mt-1.5 grid grid-cols-2 gap-2">
                  {CATEGORIES.map((c) => {
                    const Icon = c.icon;
                    const active = category === c.key;
                    return (
                      <button
                        type="button"
                        key={c.key}
                        onClick={() => setCategory(c.key)}
                        className={`flex items-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-medium transition-all ${
                          active
                            ? `${CATEGORY_MAP[c.key].bg} ${CATEGORY_MAP[c.key].textDark} border-transparent shadow-sm`
                            : 'border-slate-200 bg-white text-slate-500 hover:bg-slate-50'
                        }`}
                      >
                        <Icon className="h-4 w-4" />
                        {c.label}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Hours
                </label>
                <input
                  type="number"
                  step="0.25"
                  min="0.25"
                  value={hours}
                  onChange={(e) => setHours(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100"
                />
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Notes (optional)
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="mt-1.5 w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100"
                  placeholder="What did you do?"
                />
              </div>
              {error && <p className="text-sm font-medium text-red-600">{error}</p>}
              <button
                type="submit"
                disabled={submitting}
                className="w-full rounded-xl bg-gradient-to-r from-red-500 to-rose-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-red-500/30 transition-transform hover:scale-[1.01] active:scale-95 disabled:opacity-50"
              >
                {submitting ? 'Saving...' : 'Save Session'}
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
