import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type UserPreferences } from '@/lib/supabase';
import { User, Lock, Globe, Bell, Palette, Download, Save, Check, Eye, EyeOff } from 'lucide-react';

interface Props {
  preferences: UserPreferences | null;
  onSavePreferences: (prefs: Partial<Omit<UserPreferences, 'id' | 'user_id' | 'updated_at'>>) => Promise<void>;
}

const TIMEZONES = [
  'UTC', 'Europe/London', 'Europe/Paris', 'Africa/Johannesburg', 'Africa/Lagos', 'Africa/Nairobi',
  'America/New_York', 'America/Chicago', 'America/Los_Angeles', 'Asia/Dubai', 'Asia/Kolkata', 'Asia/Tokyo', 'Australia/Sydney',
];

export function SettingsPage({ preferences, onSavePreferences }: Props) {
  const { user, signOut } = useAuth();
  const [tab, setTab] = useState<'profile' | 'preferences' | 'notifications' | 'data'>('profile');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Profile
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  // Preferences
  const [timezone, setTimezone] = useState(preferences?.timezone ?? 'UTC');
  const [theme, setTheme] = useState<'light' | 'dark'>(preferences?.theme ?? 'light');
  const [dailyTarget, setDailyTarget] = useState(String(preferences?.daily_target_hours ?? 6));
  const [minSession, setMinSession] = useState(String(preferences?.min_session_minutes ?? 15));

  // Notifications
  const [notifyDaily, setNotifyDaily] = useState(preferences?.notify_daily_target ?? true);
  const [notifyReminders, setNotifyReminders] = useState(preferences?.notify_activity_reminders ?? true);
  const [notifyWeekly, setNotifyWeekly] = useState(preferences?.notify_weekly_summary ?? true);
  const [reminderTime, setReminderTime] = useState(preferences?.reminder_time ?? '08:00');

  async function handleSavePreferences() {
    setSaving(true);
    setSaved(false);
    try {
      await onSavePreferences({
        timezone, theme, daily_target_hours: parseFloat(dailyTarget) || 6,
        min_session_minutes: parseInt(minSession) || 15,
        notify_daily_target: notifyDaily, notify_activity_reminders: notifyReminders,
        notify_weekly_summary: notifyWeekly, reminder_time: reminderTime,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  }

  async function handlePasswordChange(e: React.FormEvent) {
    e.preventDefault();
    setPasswordError(null);
    setPasswordSuccess(false);
    if (newPassword.length < 6) { setPasswordError('Password must be at least 6 characters.'); return; }
    if (newPassword !== confirmPassword) { setPasswordError('Passwords do not match.'); return; }
    setSaving(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      setPasswordSuccess(true);
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPasswordSuccess(false), 3000);
    } catch (err) {
      setPasswordError(err instanceof Error ? err.message : 'Failed to update password');
    } finally {
      setSaving(false);
    }
  }

  function handleExport() {
    const data = { user: user?.email, preferences, exported_at: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'great-escape-data.json';
    a.click();
    URL.revokeObjectURL(url);
  }

  const tabs = [
    { key: 'profile' as const, label: 'Profile', icon: <User className="h-4 w-4" /> },
    { key: 'preferences' as const, label: 'Preferences', icon: <Palette className="h-4 w-4" /> },
    { key: 'notifications' as const, label: 'Notifications', icon: <Bell className="h-4 w-4" /> },
    { key: 'data' as const, label: 'Data', icon: <Download className="h-4 w-4" /> },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-extrabold text-slate-800">Settings</h2>
        <p className="text-sm text-slate-500">Manage your account and preferences.</p>
      </div>

      <div className="flex gap-1 overflow-x-auto rounded-2xl border border-slate-200 bg-white p-1 shadow-sm">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-bold whitespace-nowrap ${tab === t.key ? 'bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {tab === 'profile' && (
        <div className="space-y-4">
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-red-500 to-blue-600 text-white">
                <User className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800">{user?.email}</p>
                <p className="text-xs text-slate-400">Signed in</p>
              </div>
            </div>
          </div>

          <form onSubmit={handlePasswordChange} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-3 flex items-center gap-2">
              <Lock className="h-4 w-4 text-slate-400" />
              <h3 className="text-sm font-bold text-slate-800">Change Password</h3>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">New Password</label>
                <div className="relative mt-1">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 pr-10 text-sm outline-none focus:border-red-400"
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Confirm Password</label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400"
                />
              </div>
              {passwordError && <p className="text-sm font-medium text-red-600">{passwordError}</p>}
              {passwordSuccess && <p className="flex items-center gap-1 text-sm font-medium text-emerald-600"><Check className="h-4 w-4" /> Password updated successfully.</p>}
              <button type="submit" disabled={saving} className="rounded-xl bg-gradient-to-r from-red-500 to-rose-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-red-500/30 disabled:opacity-50">
                {saving ? 'Updating...' : 'Update Password'}
              </button>
            </div>
          </form>

          <button
            onClick={signOut}
            className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"
          >
            Sign Out
          </button>
        </div>
      )}

      {tab === 'preferences' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-4 flex items-center gap-2">
            <Globe className="h-4 w-4 text-slate-400" />
            <h3 className="text-sm font-bold text-slate-800">Regional & Display</h3>
          </div>
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Timezone</label>
              <select value={timezone} onChange={(e) => setTimezone(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400">
                {TIMEZONES.map((tz) => <option key={tz} value={tz}>{tz}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Theme</label>
              <div className="mt-1.5 flex gap-2">
                {(['light', 'dark'] as const).map((t) => (
                  <button key={t} onClick={() => setTheme(t)} className={`flex-1 rounded-xl border px-3 py-2.5 text-sm font-medium capitalize ${theme === t ? 'border-transparent bg-blue-100 text-blue-700' : 'border-slate-200 bg-white text-slate-500'}`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Daily Target (h)</label>
                <input type="number" min="1" step="0.5" value={dailyTarget} onChange={(e) => setDailyTarget(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Min Session (min)</label>
                <input type="number" min="1" step="1" value={minSession} onChange={(e) => setMinSession(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
              </div>
            </div>
          </div>
          <SaveButton saving={saving} saved={saved} onClick={handleSavePreferences} />
        </div>
      )}

      {tab === 'notifications' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-4 flex items-center gap-2">
            <Bell className="h-4 w-4 text-slate-400" />
            <h3 className="text-sm font-bold text-slate-800">Notification Preferences</h3>
          </div>
          <div className="space-y-3">
            <ToggleRow label="Daily target reminders" desc="Get reminded about your daily hour goals" checked={notifyDaily} onChange={setNotifyDaily} />
            <ToggleRow label="Activity reminders" desc="Reminders for scheduled activities" checked={notifyReminders} onChange={setNotifyReminders} />
            <ToggleRow label="Weekly summary" desc="Sunday performance report notification" checked={notifyWeekly} onChange={setNotifyWeekly} />
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Daily Reminder Time</label>
              <input type="time" value={reminderTime} onChange={(e) => setReminderTime(e.target.value)} className="mt-1 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-400" />
            </div>
          </div>
          <SaveButton saving={saving} saved={saved} onClick={handleSavePreferences} />
        </div>
      )}

      {tab === 'data' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-4 flex items-center gap-2">
            <Download className="h-4 w-4 text-slate-400" />
            <h3 className="text-sm font-bold text-slate-800">Data Export</h3>
          </div>
          <p className="text-sm text-slate-500">Download your account data and preferences as a JSON file.</p>
          <button onClick={handleExport} className="mt-3 inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100">
            <Download className="h-4 w-4" /> Export My Data
          </button>
        </div>
      )}
    </div>
  );
}

function ToggleRow({ label, desc, checked, onChange }: { label: string; desc: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3">
      <div>
        <p className="text-sm font-semibold text-slate-700">{label}</p>
        <p className="text-xs text-slate-400">{desc}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative h-6 w-11 rounded-full transition-colors ${checked ? 'bg-emerald-500' : 'bg-slate-300'}`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-sm transition-transform ${checked ? 'translate-x-5' : 'translate-x-0.5'}`} />
      </button>
    </div>
  );
}

function SaveButton({ saving, saved, onClick }: { saving: boolean; saved: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      disabled={saving}
      className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-red-500/30 disabled:opacity-50"
    >
      {saved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
      {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Changes'}
    </button>
  );
}
