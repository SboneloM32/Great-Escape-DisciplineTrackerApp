import { useEffect, useState } from 'react';
import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import type { Category, ActiveTimer } from '@/lib/supabase';
import { Play, Pause, Square, CheckCircle2, Timer as TimerIcon, X } from 'lucide-react';

interface Props {
  activeTimer: ActiveTimer | null;
  onStart: (category: Category, notes?: string | null) => Promise<void>;
  onPause: () => Promise<void>;
  onResume: () => Promise<void>;
  onComplete: (notes?: string | null) => Promise<void>;
  onCancel: () => Promise<void>;
}

function formatTime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function LiveTimer({ activeTimer, onStart, onPause, onResume, onComplete, onCancel }: Props) {
  const [selectedCategory, setSelectedCategory] = useState<Category>('studying');
  const [notes, setNotes] = useState('');
  const [liveSeconds, setLiveSeconds] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!activeTimer) {
      setLiveSeconds(0);
      return;
    }
    const base = activeTimer.elapsed_seconds;
    if (activeTimer.status === 'paused') {
      setLiveSeconds(base);
      return;
    }
    const startedAt = new Date(activeTimer.started_at).getTime();
    const tick = () => {
      const now = Date.now();
      setLiveSeconds(base + Math.floor((now - startedAt) / 1000));
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [activeTimer]);

  async function handleStart() {
    setError(null);
    setSubmitting(true);
    try {
      await onStart(selectedCategory, notes.trim() || null);
      setNotes('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start timer');
    } finally {
      setSubmitting(false);
    }
  }

  async function handlePause() {
    setSubmitting(true);
    try { await onPause(); } finally { setSubmitting(false); }
  }

  async function handleResume() {
    setSubmitting(true);
    try { await onResume(); } finally { setSubmitting(false); }
  }

  async function handleComplete() {
    setSubmitting(true);
    try {
      await onComplete(notes.trim() || null);
      setNotes('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to complete session');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleCancel() {
    setSubmitting(true);
    try { await onCancel(); } finally { setSubmitting(false); }
  }

  if (activeTimer) {
    const cfg = CATEGORY_MAP[activeTimer.category];
    const Icon = cfg.icon;
    const isPaused = activeTimer.status === 'paused';

    return (
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-800">Active Session</h3>
          <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ${
            isPaused ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
          }`}>
            <span className={`h-1.5 w-1.5 rounded-full ${isPaused ? 'bg-amber-500' : 'bg-emerald-500 animate-pulse'}`} />
            {isPaused ? 'Paused' : 'Running'}
          </span>
        </div>

        <div className="mt-5 flex flex-col items-center">
          <div className={`flex items-center gap-2 ${cfg.text}`}>
            <Icon className="h-5 w-5" />
            <span className="text-sm font-semibold">{cfg.label}</span>
          </div>
          <div className={`mt-3 font-mono text-5xl font-bold tabular-nums ${isPaused ? 'text-slate-400' : 'text-slate-800'}`}>
            {formatTime(liveSeconds)}
          </div>
          <p className="mt-1 text-xs text-slate-400">
            {Math.floor(liveSeconds / 3600)}h {Math.floor((liveSeconds % 3600) / 60)}m {liveSeconds % 60}s elapsed
          </p>
        </div>

        <div className="mt-4">
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add a note for this session (optional)"
            className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100"
          />
        </div>

        {error && <p className="mt-3 text-sm font-medium text-red-600">{error}</p>}

        <div className="mt-4 grid grid-cols-3 gap-2">
          {isPaused ? (
            <button
              onClick={handleResume}
              disabled={submitting}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-blue-500 px-3 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-blue-600 disabled:opacity-50"
            >
              <Play className="h-4 w-4" /> Resume
            </button>
          ) : (
            <button
              onClick={handlePause}
              disabled={submitting}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-amber-500 px-3 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-amber-600 disabled:opacity-50"
            >
              <Pause className="h-4 w-4" /> Pause
            </button>
          )}
          <button
            onClick={handleComplete}
            disabled={submitting}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-emerald-500 px-3 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-600 disabled:opacity-50"
          >
            <CheckCircle2 className="h-4 w-4" /> Done
          </button>
          <button
            onClick={handleCancel}
            disabled={submitting}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm font-bold text-slate-500 shadow-sm transition-colors hover:bg-slate-50 disabled:opacity-50"
          >
            <X className="h-4 w-4" /> Cancel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-center gap-2">
        <TimerIcon className="h-5 w-5 text-blue-500" />
        <h3 className="text-lg font-bold text-slate-800">Start a Live Session</h3>
      </div>
      <p className="mt-1 text-sm text-slate-500">
        Pick a category and start a real-time timer. Pause anytime and complete when done —
        the hours are logged automatically.
      </p>

      <div className="mt-4">
        <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Category</label>
        <div className="mt-1.5 grid grid-cols-2 gap-2">
          {CATEGORIES.map((c) => {
            const Icon = c.icon;
            const active = selectedCategory === c.key;
            return (
              <button
                type="button"
                key={c.key}
                onClick={() => setSelectedCategory(c.key)}
                className={`flex items-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-medium transition-all ${
                  active
                    ? `${CATEGORY_MAP[c.key].bg} ${CATEGORY_MAP[c.key].textDark} border-transparent shadow-sm`
                    : 'border-slate-200 bg-white text-slate-500 hover:bg-slate-50'
                }`}
              >
                <Icon className="h-4 w-4" />
                {c.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-4">
        <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Notes (optional)</label>
        <input
          type="text"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="What are you working on?"
          className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100"
        />
      </div>

      {error && <p className="mt-3 text-sm font-medium text-red-600">{error}</p>}

      <button
        onClick={handleStart}
        disabled={submitting}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-blue-500/30 transition-transform hover:scale-[1.01] active:scale-95 disabled:opacity-50"
      >
        <Play className="h-4 w-4" />
        {submitting ? 'Starting...' : 'Start Timer'}
      </button>
    </div>
  );
}
