import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { AuthPage } from '@/components/AuthPage';
import { useProgrammeData, ensureDefaultGoals } from '@/hooks/useProgrammeData';
import { useProgress, useOverallStats } from '@/hooks/useProgress';
import { currentWeekNumber } from '@/lib/programme';
import { HeroStats, CategoryLegend } from '@/components/HeroStats';
import { OverallDonut } from '@/components/OverallDonut';
import { WeekTimeline } from '@/components/WeekTimeline';
import { WeekDetail } from '@/components/WeekDetail';
import { LogSessionModal } from '@/components/LogSessionModal';
import { SessionList, SessionListLegend } from '@/components/SessionList';
import { GoalsEditor } from '@/components/GoalsEditor';
import { StartDateEditor } from '@/components/StartDateEditor';
import { DisciplineCharacter, computeCharacterState } from '@/components/DisciplineCharacter';
import { LiveTimer } from '@/components/LiveTimer';
import { QuotesPage } from '@/components/QuotesPage';
import { PlannerPage } from '@/components/PlannerPage';
import { AnalyticsPage } from '@/components/AnalyticsPage';
import { SettingsPage } from '@/components/SettingsPage';
import { SessionHistory } from '@/components/SessionHistory';
import { Compass, Settings2, Sparkles, Flame, LogOut, LayoutDashboard, Timer as TimerIcon, Quote, CalendarDays, BarChart3, Cog, Plus } from 'lucide-react';

type Tab = 'home' | 'timer' | 'planner' | 'analytics' | 'settings';

function App() {
  const { user, loading: authLoading, signOut } = useAuth();
  const data = useProgrammeData(user);
  const {
    settings, sessions, goals, activeTimer, plannerItems, routines, preferences,
    reports, loading, error,
    setStartDate, setGoal, addSession, updateSession, deleteSession,
    startTimer, pauseTimer, resumeTimer, completeTimer, cancelTimer,
    addPlannerItem, updatePlannerItem, deletePlannerItem,
    addRoutine, deleteRoutine,
    savePreferences, generateWeeklyReport,
  } = data;

  const [selectedWeek, setSelectedWeek] = useState(1);
  const [goalsOpen, setGoalsOpen] = useState(false);
  const [tab, setTab] = useState<Tab>('home');
  const [showQuotes, setShowQuotes] = useState(false);

  const startDate = settings?.start_date ?? null;
  const currentWeek = startDate ? currentWeekNumber(startDate) : 0;

  useEffect(() => {
    if (startDate && goals.length === 0) ensureDefaultGoals(goals, setGoal);
  }, [startDate, goals.length, setGoal]);

  useEffect(() => {
    if (currentWeek > 0) setSelectedWeek(currentWeek);
  }, [currentWeek]);

  const progress = useProgress(startDate, sessions, goals);
  const stats = useOverallStats(progress);
  const characterState = useMemo(() => computeCharacterState(progress), [progress]);

  const weekSessions = useMemo(() => {
    if (!startDate) return [];
    const w = progress.find((p) => p.week === selectedWeek);
    if (!w) return [];
    return sessions.filter((s) => s.date >= w.range.start && s.date <= w.range.end);
  }, [sessions, progress, selectedWeek, startDate]);

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-slate-200 border-t-red-500" />
      </div>
    );
  }

  if (!user) return <AuthPage />;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-blue-200/30 blur-[120px]" />
        <div className="absolute top-1/3 -right-40 h-[400px] w-[400px] rounded-full bg-red-200/30 blur-[120px]" />
        <div className="absolute bottom-0 -left-40 h-[400px] w-[400px] rounded-full bg-blue-100/40 blur-[120px]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-4 pb-24 pt-5 sm:px-6 sm:py-8 lg:pb-8">
        {/* Header */}
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-red-500 to-blue-600 shadow-lg shadow-red-500/20">
              <Compass className="h-5 w-5 text-white" />
            </span>
            <div>
              <h1 className="text-base font-extrabold leading-tight text-slate-800 sm:text-lg">The Great Escape</h1>
              <p className="text-xs text-slate-500">{user.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {startDate && <StartDateEditor startDate={startDate} onSave={setStartDate} />}
            <button
              onClick={() => setGoalsOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-600 shadow-sm hover:bg-slate-50"
            >
              <Settings2 className="h-4 w-4 text-blue-500" />
              <span className="hidden sm:inline">Targets</span>
            </button>
            <LogSessionModal onAdd={addSession} />
            <button onClick={signOut} className="inline-flex items-center rounded-full border border-slate-200 bg-white p-2 text-slate-500 shadow-sm hover:bg-slate-50" title="Sign out">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </header>

        {error && (
          <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">{error}</div>
        )}

        {loading ? (
          <LoadingState />
        ) : (
          <main className="mt-5 space-y-6">
            {/* HOME TAB */}
            {tab === 'home' && (
              <>
                <section className="animate-fade-in-up overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                  <div className="grid grid-cols-1 lg:grid-cols-3">
                    <div className="relative flex flex-col items-center justify-center border-b border-slate-100 bg-gradient-to-b from-blue-50 to-white p-6 lg:border-b-0 lg:border-r">
                      <div className="absolute left-4 top-4">
                        <span className="inline-flex items-center gap-1 rounded-full bg-orange-100 px-2.5 py-1 text-xs font-bold text-orange-600">
                          <Flame className="h-3 w-3" />
                          {characterState.streak > 0 ? `${characterState.streak} week streak` : 'Start your streak'}
                        </span>
                      </div>
                      <DisciplineCharacter state={characterState} />
                      <p className="mt-3 max-w-[220px] text-center text-xs text-slate-500">
                        {characterState.hasCrown ? 'Crown earned! Keep going!' : 'Complete 4 straight weeks at 75%+ to earn a crown.'}
                      </p>
                    </div>
                    <div className="col-span-1 p-5 sm:p-6 lg:col-span-2">
                      <div className="flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-red-500" />
                        <span className="text-xs font-bold uppercase tracking-wider text-red-500">
                          {currentWeek > 0 ? `Week ${currentWeek} of 5` : 'Ready to begin'}
                        </span>
                      </div>
                      <h2 className="mt-2 text-2xl font-extrabold text-slate-800 sm:text-3xl">{motivationalMessage(currentWeek, stats.percent)}</h2>
                      <p className="mt-2 max-w-lg text-sm text-slate-500">Track your hours across studying, socialising, exercising and worship.</p>
                      <div className="mt-4"><HeroStats stats={stats} currentWeek={currentWeek} /></div>
                      <div className="mt-5"><OverallDonut stats={stats} /></div>
                    </div>
                  </div>
                </section>

                <section>
                  <div className="mb-3 flex items-center justify-between">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">5-Week Journey</h3>
                    <CategoryLegend />
                  </div>
                  <WeekTimeline progress={progress} currentWeek={currentWeek} onSelectWeek={setSelectedWeek} selectedWeek={selectedWeek} />
                </section>

                <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                  <div className="animate-fade-in-up">
                    {progress[selectedWeek - 1] && <WeekDetail week={progress[selectedWeek - 1]} />}
                  </div>
                  <div className="animate-fade-in-up">
                    <div className="mb-3 flex items-center justify-between">
                      <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">Sessions · Week {selectedWeek}</h3>
                      <SessionListLegend />
                    </div>
                    <SessionList sessions={weekSessions} onDelete={deleteSession} />
                  </div>
                </section>

                <button
                  onClick={() => setShowQuotes(true)}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white py-3 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"
                >
                  <Quote className="h-4 w-4 text-red-500" /> Quote of the Day
                </button>
              </>
            )}

            {/* TIMER TAB */}
            {tab === 'timer' && (
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                <div className="animate-fade-in-up">
                  <LiveTimer
                    activeTimer={activeTimer}
                    onStart={startTimer}
                    onPause={pauseTimer}
                    onResume={resumeTimer}
                    onComplete={completeTimer}
                    onCancel={cancelTimer}
                  />
                </div>
                <div className="animate-fade-in-up">
                  <SessionHistory sessions={sessions} onDelete={deleteSession} onUpdate={updateSession} />
                </div>
              </div>
            )}

            {/* PLANNER TAB */}
            {tab === 'planner' && (
              <div className="animate-fade-in-up">
                <PlannerPage
                  plannerItems={plannerItems}
                  routines={routines}
                  onAdd={addPlannerItem}
                  onUpdate={updatePlannerItem}
                  onDelete={deletePlannerItem}
                  onAddRoutine={addRoutine}
                  onDeleteRoutine={deleteRoutine}
                />
              </div>
            )}

            {/* ANALYTICS TAB */}
            {tab === 'analytics' && (
              <div className="animate-fade-in-up">
                <AnalyticsPage
                  startDate={startDate}
                  sessions={sessions}
                  goals={goals}
                  reports={reports}
                  onGenerateReport={generateWeeklyReport}
                />
              </div>
            )}

            {/* SETTINGS TAB */}
            {tab === 'settings' && (
              <div className="animate-fade-in-up">
                <SettingsPage preferences={preferences} onSavePreferences={savePreferences} />
              </div>
            )}

            <footer className="pt-2 text-center text-xs font-medium text-slate-400">
              The Great Escape · Your discipline, your data
            </footer>
          </main>
        )}
      </div>

      {/* Quotes modal */}
      {showQuotes && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setShowQuotes(false)} />
          <div className="relative max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl scrollbar-thin">
            <button onClick={() => setShowQuotes(false)} className="absolute right-4 top-4 z-10 rounded-full bg-white/80 p-1.5 text-slate-400 hover:bg-slate-100">
              <LogOut className="h-4 w-4 rotate-180" />
            </button>
            <QuotesPage />
          </div>
        </div>
      )}

      {/* Goals editor */}
      {startDate && (
        <GoalsEditor startDate={startDate} goals={goals} onSave={setGoal} open={goalsOpen} onClose={() => setGoalsOpen(false)} />
      )}

      {/* Mobile bottom navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/90 backdrop-blur-lg lg:hidden">
        <div className="flex items-center justify-around px-2 py-2">
          <NavTab active={tab === 'home'} onClick={() => setTab('home')} icon={<LayoutDashboard className="h-5 w-5" />} label="Home" />
          <NavTab active={tab === 'timer'} onClick={() => setTab('timer')} icon={<TimerIcon className="h-5 w-5" />} label="Timer" badge={!!activeTimer} />
          <NavTab active={tab === 'planner'} onClick={() => setTab('planner')} icon={<CalendarDays className="h-5 w-5" />} label="Planner" />
          <NavTab active={tab === 'analytics'} onClick={() => setTab('analytics')} icon={<BarChart3 className="h-5 w-5" />} label="Stats" />
          <NavTab active={tab === 'settings'} onClick={() => setTab('settings')} icon={<Cog className="h-5 w-5" />} label="Settings" />
        </div>
      </nav>

      {/* Desktop top tabs */}
      <div className="fixed bottom-6 left-1/2 z-30 hidden -translate-x-1/2 lg:block">
        <nav className="flex gap-1 rounded-2xl border border-slate-200 bg-white/90 p-1 shadow-lg backdrop-blur-lg">
          <DesktopTab active={tab === 'home'} onClick={() => setTab('home')} icon={<LayoutDashboard className="h-4 w-4" />} label="Home" />
          <DesktopTab active={tab === 'timer'} onClick={() => setTab('timer')} icon={<TimerIcon className="h-4 w-4" />} label="Timer" badge={!!activeTimer} />
          <DesktopTab active={tab === 'planner'} onClick={() => setTab('planner')} icon={<CalendarDays className="h-4 w-4" />} label="Planner" />
          <DesktopTab active={tab === 'analytics'} onClick={() => setTab('analytics')} icon={<BarChart3 className="h-4 w-4" />} label="Analytics" />
          <DesktopTab active={tab === 'settings'} onClick={() => setTab('settings')} icon={<Cog className="h-4 w-4" />} label="Settings" />
        </nav>
      </div>
    </div>
  );
}

function NavTab({ active, onClick, icon, label, badge }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string; badge?: boolean }) {
  return (
    <button onClick={onClick} className={`relative flex flex-col items-center gap-0.5 px-2 py-1.5 transition-colors ${active ? 'text-red-500' : 'text-slate-400'}`}>
      {icon}
      <span className="text-[10px] font-bold">{label}</span>
      {badge && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-emerald-500" />}
    </button>
  );
}

function DesktopTab({ active, onClick, icon, label, badge }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string; badge?: boolean }) {
  return (
    <button onClick={onClick} className={`relative flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition-all ${active ? 'bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}>
      {icon}
      {label}
      {badge && <span className="ml-0.5 h-2 w-2 rounded-full bg-emerald-500" />}
    </button>
  );
}

function motivationalMessage(week: number, percent: number): string {
  if (week === 0) return 'Your great escape begins today.';
  if (percent >= 100) return 'Week conquered. On to the next.';
  if (percent >= 75) return 'Almost there — finish strong.';
  if (percent >= 50) return 'Halfway through. Keep pushing.';
  if (percent >= 25) return 'Building momentum. Stay consistent.';
  return 'Every hour counts. Start now.';
}

function LoadingState() {
  return (
    <div className="mt-6 space-y-6">
      <div className="h-48 rounded-3xl skeleton" />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-32 rounded-2xl skeleton" />)}
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="h-64 rounded-3xl skeleton" />
        <div className="h-64 rounded-3xl skeleton" />
      </div>
    </div>
  );
}

export default App;
