import { useMemo } from 'react';
import type { Session, WeeklyGoal, Category } from '@/lib/supabase';
import { CATEGORIES, CATEGORY_MAP } from '@/lib/categories';
import { weekDateRange, parseDate, TOTAL_WEEKS } from '@/lib/programme';

export interface WeekProgress {
  week: number;
  range: { start: string; end: string };
  categories: Record<Category, { logged: number; target: number; percent: number }>;
  totalLogged: number;
  totalTarget: number;
  overallPercent: number;
}

export function useProgress(
  startDate: string | null,
  sessions: Session[],
  goals: WeeklyGoal[],
): WeekProgress[] {
  return useMemo(() => {
    if (!startDate) return [];
    const result: WeekProgress[] = [];
    for (let w = 1; w <= TOTAL_WEEKS; w++) {
      const range = weekDateRange(startDate, w);
      const weekStart = parseDate(range.start);
      const weekEnd = parseDate(range.end);
      const categories = CATEGORIES.reduce(
        (acc, cat) => {
          const target = goals.find((g) => g.week_number === w && g.category === cat.key)?.target_hours ?? 0;
          const logged = sessions
            .filter((s) => {
              const d = parseDate(s.date);
              return s.category === cat.key && d >= weekStart && d <= weekEnd;
            })
            .reduce((sum, s) => sum + Number(s.hours), 0);
          const percent = target > 0 ? Math.min((logged / target) * 100, 100) : 0;
          acc[cat.key] = { logged, target, percent };
          return acc;
        },
        {} as Record<Category, { logged: number; target: number; percent: number }>,
      );
      const totalLogged = CATEGORIES.reduce((sum, c) => sum + categories[c.key].logged, 0);
      const totalTarget = CATEGORIES.reduce((sum, c) => sum + categories[c.key].target, 0);
      const overallPercent = totalTarget > 0 ? Math.min((totalLogged / totalTarget) * 100, 100) : 0;
      result.push({ week: w, range, categories, totalLogged, totalTarget, overallPercent });
    }
    return result;
  }, [startDate, sessions, goals]);
}

export interface OverallStats {
  totalLogged: number;
  totalTarget: number;
  percent: number;
  byCategory: Record<Category, { logged: number; target: number; percent: number; color: string }>;
}

export function useOverallStats(progress: WeekProgress[]): OverallStats {
  return useMemo(() => {
    const totalLogged = progress.reduce((s, w) => s + w.totalLogged, 0);
    const totalTarget = progress.reduce((s, w) => s + w.totalTarget, 0);
    const byCategory = CATEGORIES.reduce(
      (acc, cat) => {
        const logged = progress.reduce((s, w) => s + w.categories[cat.key].logged, 0);
        const target = progress.reduce((s, w) => s + w.categories[cat.key].target, 0);
        const percent = target > 0 ? Math.min((logged / target) * 100, 100) : 0;
        acc[cat.key] = { logged, target, percent, color: CATEGORY_MAP[cat.key].accent };
        return acc;
      },
      {} as OverallStats['byCategory'],
    );
    return {
      totalLogged,
      totalTarget,
      percent: totalTarget > 0 ? Math.min((totalLogged / totalTarget) * 100, 100) : 0,
      byCategory,
    };
  }, [progress]);
}
