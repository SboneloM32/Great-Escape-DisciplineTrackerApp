import { useCallback, useEffect, useState } from 'react';
import {
  supabase,
  type ProgrammeSettings,
  type Session,
  type WeeklyGoal,
  type Category,
  type ActiveTimer,
  type PlannerItem,
  type Routine,
  type UserPreferences,
  type WeeklyReport,
  type NotificationItem,
  type Profile,
} from '@/lib/supabase';
import { TOTAL_WEEKS } from '@/lib/programme';
import type { User } from '@supabase/supabase-js';

export interface ProgrammeData {
  settings: ProgrammeSettings | null;
  sessions: Session[];
  goals: WeeklyGoal[];
  activeTimer: ActiveTimer | null;
  plannerItems: PlannerItem[];
  routines: Routine[];
  preferences: UserPreferences | null;
  reports: WeeklyReport[];
  notifications: NotificationItem[];
  profile: Profile | null;
  loading: boolean;
  error: string | null;
  setStartDate: (date: string) => Promise<void>;
  setGoal: (week: number, category: Category, hours: number) => Promise<void>;
  addSession: (session: Omit<Session, 'id' | 'created_at' | 'user_id'>) => Promise<void>;
  updateSession: (id: string, patch: Partial<Omit<Session, 'id' | 'created_at' | 'user_id'>>) => Promise<void>;
  deleteSession: (id: string) => Promise<void>;
  startTimer: (category: Category, notes?: string | null) => Promise<void>;
  pauseTimer: () => Promise<void>;
  resumeTimer: () => Promise<void>;
  completeTimer: (notes?: string | null) => Promise<void>;
  cancelTimer: () => Promise<void>;
  addPlannerItem: (item: Omit<PlannerItem, 'id' | 'created_at' | 'user_id'>) => Promise<void>;
  updatePlannerItem: (id: string, patch: Partial<Omit<PlannerItem, 'id' | 'created_at' | 'user_id'>>) => Promise<void>;
  deletePlannerItem: (id: string) => Promise<void>;
  addRoutine: (routine: Omit<Routine, 'id' | 'created_at' | 'user_id'>) => Promise<void>;
  updateRoutine: (id: string, patch: Partial<Omit<Routine, 'id' | 'created_at' | 'user_id'>>) => Promise<void>;
  deleteRoutine: (id: string) => Promise<void>;
  savePreferences: (prefs: Partial<Omit<UserPreferences, 'id' | 'user_id' | 'updated_at'>>) => Promise<void>;
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  generateWeeklyReport: (weekNumber: number) => Promise<void>;
  updateProfile: (patch: Partial<Omit<Profile, 'id' | 'created_at' | 'updated_at'>>) => Promise<void>;
  deleteAccount: () => Promise<void>;
  refresh: () => Promise<void>;
}

export function useProgrammeData(user: User | null): ProgrammeData {
  const [settings, setSettings] = useState<ProgrammeSettings | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [goals, setGoals] = useState<WeeklyGoal[]>([]);
  const [activeTimer, setActiveTimer] = useState<ActiveTimer | null>(null);
  const [plannerItems, setPlannerItems] = useState<PlannerItem[]>([]);
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [reports, setReports] = useState<WeeklyReport[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!user) {
      setSettings(null); setSessions([]); setGoals([]); setActiveTimer(null);
      setPlannerItems([]); setRoutines([]); setPreferences(null);
      setReports([]); setNotifications([]); setProfile(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const [sRes, sessRes, gRes, tRes, pRes, rRes, prefRes, repRes, nRes, profRes] = await Promise.all([
        supabase.from('programme_settings').select('*').maybeSingle(),
        supabase.from('sessions').select('*').order('date', { ascending: false }),
        supabase.from('weekly_goals').select('*'),
        supabase.from('active_timers').select('*').maybeSingle(),
        supabase.from('planner_items').select('*').order('date', { ascending: true }),
        supabase.from('routines').select('*').order('day_of_week', { ascending: true }),
        supabase.from('user_preferences').select('*').maybeSingle(),
        supabase.from('weekly_reports').select('*').order('week_number', { ascending: true }),
        supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50),
        supabase.from('profiles').select('*').maybeSingle(),
      ]);
      if (profRes.error) throw profRes.error;

      if (sRes.error) throw sRes.error;
      if (sessRes.error) throw sessRes.error;
      if (gRes.error) throw gRes.error;
      if (tRes.error) throw tRes.error;
      if (pRes.error) throw pRes.error;
      if (rRes.error) throw rRes.error;
      if (prefRes.error) throw prefRes.error;
      if (repRes.error) throw repRes.error;
      if (nRes.error) throw nRes.error;

      setSettings(sRes.data as ProgrammeSettings | null);
      setSessions((sessRes.data as Session[]) ?? []);
      setGoals((gRes.data as WeeklyGoal[]) ?? []);
      setActiveTimer((tRes.data as ActiveTimer | null) ?? null);
      setPlannerItems((pRes.data as PlannerItem[]) ?? []);
      setRoutines((rRes.data as Routine[]) ?? []);
      setPreferences((prefRes.data as UserPreferences | null) ?? null);
      setReports((repRes.data as WeeklyReport[]) ?? []);
      setNotifications((nRes.data as NotificationItem[]) ?? []);
      setProfile((profRes.data as Profile | null) ?? null);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load data';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => { void refresh(); }, [refresh]);

  const setStartDate = useCallback(async (date: string) => {
    const { error: err } = await supabase
      .from('programme_settings').upsert({ id: 1, start_date: date, updated_at: new Date().toISOString() });
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const setGoal = useCallback(async (week: number, category: Category, hours: number) => {
    const existing = goals.find((g) => g.week_number === week && g.category === category);
    if (existing) {
      const { error: err } = await supabase.from('weekly_goals').update({ target_hours: hours }).eq('id', existing.id);
      if (err) throw err;
    } else {
      const { error: err } = await supabase.from('weekly_goals').insert({ week_number: week, category, target_hours: hours });
      if (err) throw err;
    }
    await refresh();
  }, [goals, refresh]);

  const addSession = useCallback(async (session: Omit<Session, 'id' | 'created_at' | 'user_id'>) => {
    const { error: err } = await supabase.from('sessions').insert(session);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const updateSession = useCallback(async (id: string, patch: Partial<Omit<Session, 'id' | 'created_at' | 'user_id'>>) => {
    const { error: err } = await supabase.from('sessions').update(patch).eq('id', id);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const deleteSession = useCallback(async (id: string) => {
    const { error: err } = await supabase.from('sessions').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const startTimer = useCallback(async (category: Category, notes?: string | null) => {
    if (activeTimer) throw new Error('A timer is already running.');
    const { error: err } = await supabase.from('active_timers')
      .insert({ category, status: 'active', started_at: new Date().toISOString(), elapsed_seconds: 0, notes: notes ?? null });
    if (err) throw err;
    await refresh();
  }, [activeTimer, refresh]);

  const pauseTimer = useCallback(async () => {
    if (!activeTimer) return;
    const now = new Date();
    const startedAt = new Date(activeTimer.started_at);
    const add = activeTimer.status === 'active' ? Math.floor((now.getTime() - startedAt.getTime()) / 1000) : 0;
    const newElapsed = activeTimer.elapsed_seconds + add;
    const { error: err } = await supabase.from('active_timers')
      .update({ status: 'paused', paused_at: now.toISOString(), elapsed_seconds: newElapsed }).eq('id', activeTimer.id);
    if (err) throw err;
    await refresh();
  }, [activeTimer, refresh]);

  const resumeTimer = useCallback(async () => {
    if (!activeTimer || activeTimer.status !== 'paused') return;
    const { error: err } = await supabase.from('active_timers')
      .update({ status: 'active', started_at: new Date().toISOString(), paused_at: null }).eq('id', activeTimer.id);
    if (err) throw err;
    await refresh();
  }, [activeTimer, refresh]);

  const completeTimer = useCallback(async (notes?: string | null) => {
    if (!activeTimer) return;
    const now = new Date();
    const startedAt = new Date(activeTimer.started_at);
    const add = activeTimer.status === 'active' ? Math.floor((now.getTime() - startedAt.getTime()) / 1000) : 0;
    const totalSeconds = activeTimer.elapsed_seconds + add;
    const hours = +(totalSeconds / 3600).toFixed(2);
    if (hours > 0) {
      const todayStr = now.toISOString().slice(0, 10);
      const { error: sessionErr } = await supabase.from('sessions').insert({
        date: todayStr, category: activeTimer.category, hours,
        notes: notes ?? activeTimer.notes ?? null, status: 'completed',
        started_at: activeTimer.started_at, elapsed_seconds: totalSeconds,
      });
      if (sessionErr) throw sessionErr;
    }
    const { error: timerErr } = await supabase.from('active_timers').delete().eq('id', activeTimer.id);
    if (timerErr) throw timerErr;
    await refresh();
  }, [activeTimer, refresh]);

  const cancelTimer = useCallback(async () => {
    if (!activeTimer) return;
    const { error: err } = await supabase.from('active_timers').delete().eq('id', activeTimer.id);
    if (err) throw err;
    await refresh();
  }, [activeTimer, refresh]);

  const addPlannerItem = useCallback(async (item: Omit<PlannerItem, 'id' | 'created_at' | 'user_id'>) => {
    const { error: err } = await supabase.from('planner_items').insert(item);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const updatePlannerItem = useCallback(async (id: string, patch: Partial<Omit<PlannerItem, 'id' | 'created_at' | 'user_id'>>) => {
    const { error: err } = await supabase.from('planner_items').update(patch).eq('id', id);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const deletePlannerItem = useCallback(async (id: string) => {
    const { error: err } = await supabase.from('planner_items').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const addRoutine = useCallback(async (routine: Omit<Routine, 'id' | 'created_at' | 'user_id'>) => {
    const { error: err } = await supabase.from('routines').insert(routine);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const updateRoutine = useCallback(async (id: string, patch: Partial<Omit<Routine, 'id' | 'created_at' | 'user_id'>>) => {
    const { error: err } = await supabase.from('routines').update(patch).eq('id', id);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const deleteRoutine = useCallback(async (id: string) => {
    const { error: err } = await supabase.from('routines').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const savePreferences = useCallback(async (prefs: Partial<Omit<UserPreferences, 'id' | 'user_id' | 'updated_at'>>) => {
    const { error: err } = await supabase.from('user_preferences')
      .upsert({ ...prefs, updated_at: new Date().toISOString() });
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const markNotificationRead = useCallback(async (id: string) => {
    const { error: err } = await supabase.from('notifications').update({ read: true }).eq('id', id);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const markAllNotificationsRead = useCallback(async () => {
    const { error: err } = await supabase.from('notifications').update({ read: true }).eq('read', false);
    if (err) throw err;
    await refresh();
  }, [refresh]);

  const generateWeeklyReport = useCallback(async (weekNumber: number) => {
    if (!settings) throw new Error('No programme start date set');
    const { weekDateRange, parseDate } = await import('@/lib/programme');
    const range = weekDateRange(settings.start_date, weekNumber);
    const weekStart = parseDate(range.start);
    const weekEnd = parseDate(range.end);
    const weekSessions = sessions.filter((s) => {
      const d = parseDate(s.date);
      return d >= weekStart && d <= weekEnd;
    });
    const totalHours = weekSessions.reduce((sum, s) => sum + Number(s.hours), 0);
    const targetHours = goals.filter((g) => g.week_number === weekNumber).reduce((sum, g) => sum + g.target_hours, 0);
    const completionPercent = targetHours > 0 ? Math.min((totalHours / targetHours) * 100, 100) : 0;
    const sessionCount = weekSessions.length;
    const activeDays = new Set(weekSessions.map((s) => s.date)).size;
    const catBreakdown: Record<string, number> = {};
    for (const s of weekSessions) {
      catBreakdown[s.category] = (catBreakdown[s.category] ?? 0) + Number(s.hours);
    }

    let comparison: WeeklyReport['comparison'] = null;
    if (weekNumber > 1) {
      const prevRange = weekDateRange(settings.start_date, weekNumber - 1);
      const prevStart = parseDate(prevRange.start);
      const prevEnd = parseDate(prevRange.end);
      const prevSessions = sessions.filter((s) => {
        const d = parseDate(s.date);
        return d >= prevStart && d <= prevEnd;
      });
      const prevTotal = prevSessions.reduce((sum, s) => sum + Number(s.hours), 0);
      const prevTarget = goals.filter((g) => g.week_number === weekNumber - 1).reduce((sum, g) => sum + g.target_hours, 0);
      const prevCompletion = prevTarget > 0 ? Math.min((prevTotal / prevTarget) * 100, 100) : 0;
      comparison = { prev_total_hours: prevTotal, delta: totalHours - prevTotal, prev_completion: prevCompletion };
    }

    const { error: err } = await supabase.from('weekly_reports').upsert({
      week_number: weekNumber,
      total_hours: totalHours,
      target_hours: targetHours,
      completion_percent: completionPercent,
      session_count: sessionCount,
      active_days: activeDays,
      category_breakdown: catBreakdown,
      comparison,
      generated_at: new Date().toISOString(),
    });
    if (err) throw err;
    await refresh();
  }, [settings, sessions, goals, refresh]);

  const updateProfile = useCallback(async (patch: Partial<Omit<Profile, 'id' | 'created_at' | 'updated_at'>>) => {
    const { error: err } = await supabase.from('profiles').update(patch).eq('id', user?.id ?? '');
    if (err) throw err;
    await refresh();
  }, [user, refresh]);

  const deleteAccount = useCallback(async () => {
    const { error: err } = await supabase.auth.signInWithPassword({
      email: user?.email ?? '',
      password: prompt('Enter your password to confirm account deletion:') ?? '',
    });
    if (err) throw new Error('Password confirmation failed.');
    const { error: delErr } = await supabase.auth.admin.deleteUser(user?.id ?? '');
    if (delErr) throw delErr;
    await supabase.auth.signOut();
  }, [user]);

  return {
    settings, sessions, goals, activeTimer, plannerItems, routines, preferences,
    reports, notifications, profile, loading, error,
    setStartDate, setGoal, addSession, updateSession, deleteSession,
    startTimer, pauseTimer, resumeTimer, completeTimer, cancelTimer,
    addPlannerItem, updatePlannerItem, deletePlannerItem,
    addRoutine, updateRoutine, deleteRoutine,
    savePreferences, markNotificationRead, markAllNotificationsRead,
    generateWeeklyReport, updateProfile, deleteAccount, refresh,
  };
}

export function defaultGoalsForWeek(week: number): Record<Category, number> {
  const ramp = 0.8 + (week - 1) * 0.1;
  return {
    studying: Math.round(20 * ramp),
    socialising: Math.round(8 * ramp),
    exercising: Math.round(6 * ramp),
    worship: Math.round(5 * ramp),
  };
}

export function ensureDefaultGoals(
  goals: WeeklyGoal[],
  setGoal: (week: number, category: Category, hours: number) => Promise<void>,
): void {
  for (let w = 1; w <= TOTAL_WEEKS; w++) {
    const weekGoals = goals.filter((g) => g.week_number === w);
    if (weekGoals.length === 0) {
      const defaults = defaultGoalsForWeek(w);
      void setGoal(w, 'studying', defaults.studying);
      void setGoal(w, 'socialising', defaults.socialising);
      void setGoal(w, 'exercising', defaults.exercising);
      void setGoal(w, 'worship', defaults.worship);
    }
  }
}
