import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Category = 'studying' | 'socialising' | 'exercising' | 'worship';

export interface ProgrammeSettings {
  id: number;
  user_id: string;
  start_date: string;
  updated_at: string;
}

export interface WeeklyGoal {
  id: string;
  user_id: string;
  week_number: number;
  category: Category;
  target_hours: number;
  created_at: string;
}

export interface Session {
  id: string;
  user_id: string;
  date: string;
  category: Category;
  hours: number;
  notes: string | null;
  status: string;
  started_at: string | null;
  paused_at: string | null;
  elapsed_seconds: number;
  created_at: string;
  planner_item_id: string | null;
}

export interface ActiveTimer {
  id: string;
  user_id: string;
  category: Category;
  status: 'active' | 'paused';
  started_at: string;
  paused_at: string | null;
  elapsed_seconds: number;
  notes: string | null;
  created_at: string;
}

export interface PlannerItem {
  id: string;
  user_id: string;
  date: string;
  start_time: string;
  duration_minutes: number;
  category: Category;
  title: string | null;
  notes: string | null;
  completed: boolean;
  created_at: string;
}

export interface Routine {
  id: string;
  user_id: string;
  day_of_week: number;
  start_time: string;
  duration_minutes: number;
  category: Category;
  title: string | null;
  active: boolean;
  created_at: string;
}

export interface UserPreferences {
  id: string;
  user_id: string;
  timezone: string;
  theme: 'light' | 'dark';
  daily_target_hours: number;
  min_session_minutes: number;
  notify_daily_target: boolean;
  notify_activity_reminders: boolean;
  notify_weekly_summary: boolean;
  reminder_time: string;
  updated_at: string;
}

export interface WeeklyReport {
  id: string;
  user_id: string;
  week_number: number;
  total_hours: number;
  target_hours: number;
  completion_percent: number;
  session_count: number;
  active_days: number;
  category_breakdown: Record<string, number>;
  comparison: { prev_total_hours: number; delta: number; prev_completion: number } | null;
  generated_at: string;
}

export interface Profile {
  id: string;
  display_name: string | null;
  created_at: string;
  updated_at: string;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  type: 'reminder' | 'daily_target' | 'weekly_summary' | 'timer_complete';
  title: string;
  body: string | null;
  read: boolean;
  scheduled_for: string | null;
  created_at: string;
}
