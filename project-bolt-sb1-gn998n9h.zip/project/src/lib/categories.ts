import type { Category } from './supabase';
import { BookOpen, Users, Dumbbell, HandHeart } from 'lucide-react';

export interface CategoryConfig {
  key: Category;
  label: string;
  icon: typeof BookOpen;
  accent: string;
  text: string;
  textDark: string;
  bg: string;
  bgSoft: string;
  ring: string;
  bar: string;
  dot: string;
  gradient: string;
}

export const CATEGORIES: CategoryConfig[] = [
  {
    key: 'studying',
    label: 'Studying',
    icon: BookOpen,
    accent: '#2563eb',
    text: 'text-blue-600',
    textDark: 'text-blue-700',
    bg: 'bg-blue-100',
    bgSoft: 'bg-blue-50',
    ring: 'ring-blue-200',
    bar: 'bg-blue-500',
    dot: 'bg-blue-500',
    gradient: 'from-blue-500 to-blue-600',
  },
  {
    key: 'socialising',
    label: 'Socialising',
    icon: Users,
    accent: '#e11d48',
    text: 'text-rose-600',
    textDark: 'text-rose-700',
    bg: 'bg-rose-100',
    bgSoft: 'bg-rose-50',
    ring: 'ring-rose-200',
    bar: 'bg-rose-500',
    dot: 'bg-rose-500',
    gradient: 'from-rose-500 to-rose-600',
  },
  {
    key: 'exercising',
    label: 'Exercising',
    icon: Dumbbell,
    accent: '#059669',
    text: 'text-emerald-600',
    textDark: 'text-emerald-700',
    bg: 'bg-emerald-100',
    bgSoft: 'bg-emerald-50',
    ring: 'ring-emerald-200',
    bar: 'bg-emerald-500',
    dot: 'bg-emerald-500',
    gradient: 'from-emerald-500 to-emerald-600',
  },
  {
    key: 'worship',
    label: 'Worship',
    icon: HandHeart,
    accent: '#d97706',
    text: 'text-amber-600',
    textDark: 'text-amber-700',
    bg: 'bg-amber-100',
    bgSoft: 'bg-amber-50',
    ring: 'ring-amber-200',
    bar: 'bg-amber-500',
    dot: 'bg-amber-500',
    gradient: 'from-amber-500 to-amber-600',
  },
];

export const CATEGORY_MAP: Record<Category, CategoryConfig> = CATEGORIES.reduce(
  (acc, c) => {
    acc[c.key] = c;
    return acc;
  },
  {} as Record<Category, CategoryConfig>,
);
