export const TOTAL_WEEKS = 5;

export function parseDate(iso: string): Date {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function toISODate(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function todayISO(): string {
  return toISODate(new Date());
}

export function daysBetween(start: Date, end: Date): number {
  const ms = end.getTime() - start.getTime();
  return Math.floor(ms / (1000 * 60 * 60 * 24));
}

export function weekNumberForDate(startDate: string, date: string): number {
  const start = parseDate(startDate);
  const target = parseDate(date);
  const diff = daysBetween(start, target);
  if (diff < 0) return 0;
  return Math.floor(diff / 7) + 1;
}

export function currentWeekNumber(startDate: string): number {
  const start = parseDate(startDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diff = daysBetween(start, today);
  if (diff < 0) return 0;
  return Math.min(Math.floor(diff / 7) + 1, TOTAL_WEEKS);
}

export function weekDateRange(startDate: string, week: number): { start: string; end: string } {
  const start = parseDate(startDate);
  const weekStart = new Date(start);
  weekStart.setDate(weekStart.getDate() + (week - 1) * 7);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);
  return { start: toISODate(weekStart), end: toISODate(weekEnd) };
}

export function formatDateLabel(iso: string): string {
  const d = parseDate(iso);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function formatDateLong(iso: string): string {
  const d = parseDate(iso);
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
}
