export interface AthleteQuote {
  quote: string;
  author: string;
  title: string;
  image: string;
  alt: string;
}

export const QUOTES: AthleteQuote[] = [
  {
    quote: "It's not about being the best. It's about being better than you were the day before.",
    author: "Kobe Bryant",
    title: "5× NBA Champion",
    image: "https://images.pexels.com/photos/7005758/pexels-photo-7005758.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Basketball player holding medal and basketball",
  },
  {
    quote: "Champions aren't made in gyms. Champions are made from something they have deep inside them — a desire, a dream, a vision.",
    author: "Muhammad Ali",
    title: "3× World Heavyweight Champion",
    image: "https://images.pexels.com/photos/598664/pexels-photo-598664.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Boxer raising arms in victory",
  },
  {
    quote: "If you don't have confidence, you'll always find a way not to win.",
    author: "Carl Lewis",
    title: "9× Olympic Gold Medalist",
    image: "https://images.pexels.com/photos/1555354/pexels-photo-1555354.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Triumphant marathon runner crossing finish line",
  },
  {
    quote: "The only person who can stop you from reaching your goals is you.",
    author: "Mia Hamm",
    title: "2× FIFA World Cup Champion",
    image: "https://images.pexels.com/photos/29661267/pexels-photo-29661267.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Soccer player celebrating a goal",
  },
  {
    quote: "I've missed more than 9,000 shots in my career. I've lost almost 300 games. 26 times I've been trusted to take the game-winning shot and missed. I've failed over and over again in my life. And that is why I succeed.",
    author: "Michael Jordan",
    title: "6× NBA Champion",
    image: "https://images.pexels.com/photos/7005249/pexels-photo-7005249.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Athlete holding medal and basketball in studio",
  },
  {
    quote: "When you want to succeed as badly as you want to breathe, then you'll be successful.",
    author: "Eric Thomas",
    title: "Motivational Speaker & Athlete",
    image: "https://images.pexels.com/photos/4720758/pexels-photo-4720758.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Strong man lifting barbell in gym",
  },
  {
    quote: "Don't put a limit on anything. The more you dream, the further you get.",
    author: "Michael Phelps",
    title: "23× Olympic Gold Medalist",
    image: "https://images.pexels.com/photos/30550698/pexels-photo-30550698.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Swimmer celebrating victory in pool",
  },
  {
    quote: "Hard work beats talent when talent doesn't work hard.",
    author: "Tim Notke",
    title: "Basketball Coach",
    image: "https://images.pexels.com/photos/7005247/pexels-photo-7005247.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Basketball player celebrating with medal and trophy",
  },
  {
    quote: "The pain you feel today will be the strength you feel tomorrow.",
    author: "Arnold Schwarzenegger",
    title: "7× Mr. Olympia",
    image: "https://images.pexels.com/photos/4944006/pexels-photo-4944006.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Athlete lifting barbell in gym",
  },
  {
    quote: "Every morning when I wake up, I know that it's another opportunity to get better. And that's what I'm chasing.",
    author: "LeBron James",
    title: "4× NBA Champion",
    image: "https://images.pexels.com/photos/11045260/pexels-photo-11045260.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    alt: "Boxer raising hand in triumph after match",
  },
];

export function getQuoteOfDay(): AthleteQuote {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24),
  );
  return QUOTES[dayOfYear % QUOTES.length];
}
