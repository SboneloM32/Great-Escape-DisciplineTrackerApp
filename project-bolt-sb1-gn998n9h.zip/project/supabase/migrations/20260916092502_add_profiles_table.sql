/*
# Account Management: Profiles Table

1. New Tables
- `profiles`: One row per registered user, automatically created on signup.
  - `id` (uuid, primary key, matches auth.users.id)
  - `display_name` (text, nullable — user can set a display name)
  - `created_at` (timestamptz, defaults to now)
  - `updated_at` (timestamptz, auto-updated)

2. Automation
- Trigger `handle_new_user`: When a new row is inserted into `auth.users`, automatically
  inserts a matching row into `profiles` with the same id. This ensures every account
  has a profile row from the moment they register, without requiring frontend code to
  create it manually.

3. Security
- RLS enabled on `profiles`.
- Users can SELECT and UPDATE only their own profile row (auth.uid() = id).
- INSERT is allowed only for the user themselves (auth.uid() = id), so the trigger
  works and manual inserts by the owner also work.
- DELETE is allowed only for the owner (account deletion support).

4. Important Notes
- The trigger function runs as SECURITY DEFINER so it can insert into profiles even
  though the calling user has no INSERT privilege on the table directly (the trigger
  fires during signup before the session is fully established).
- The id column references auth.users(id) with ON DELETE CASCADE, so if a user is
  deleted from auth.users, their profile row is automatically removed.
- Email is NOT stored in profiles — it lives in auth.users and is accessed via the
  Supabase auth API. The profile is for display name and future account metadata only.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id) VALUES (new.id)
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Auto-update updated_at on profile changes
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
