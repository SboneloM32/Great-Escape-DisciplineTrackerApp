/*
# Create The Great Escape discipline programme tables (single-tenant, no auth)

1. New Tables
- `programme_settings`
  - Single-row config table holding the programme start date.
  - `id` (int, primary key, fixed to 1)
  - `start_date` (date, not null) — the day week 1 begins
  - `updated_at` (timestamptz)
- `weekly_goals`
  - Target hours per category per week (weeks 1–5).
  - `id` (uuid, primary key)
  - `week_number` (int 1–5, not null)
  - `category` (text, not null) — one of: studying, socialising, exercising, worship
  - `target_hours` (numeric, not null, default 0)
  - unique on (week_number, category)
- `sessions`
  - Logged hours for a given day and category.
  - `id` (uuid, primary key)
  - `date` (date, not null)
  - `category` (text, not null) — one of: studying, socialising, exercising, worship
  - `hours` (numeric, not null, check > 0)
  - `notes` (text, nullable)
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on all three tables.
- This is a personal single-tenant app with no sign-in, so the anon-key client
  must be able to read and write all data. Policies use `TO anon, authenticated`
  with `USING (true)` / `WITH CHECK (true)` because the data is intentionally
  shared within this single app instance.

3. Important Notes
- `programme_settings` is seeded with a single row (id = 1) defaulting the start
  date to today so the 5-week programme begins immediately.
- A CHECK constraint on `sessions.hours` prevents zero or negative entries.
- A CHECK constraint on `sessions.category` and `weekly_goals.category` restricts
  values to the four valid programme categories.
*/

CREATE TABLE IF NOT EXISTS programme_settings (
  id int PRIMARY KEY DEFAULT 1,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT programme_settings_single_row CHECK (id = 1)
);

ALTER TABLE programme_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_programme_settings" ON programme_settings;
CREATE POLICY "anon_select_programme_settings" ON programme_settings
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_programme_settings" ON programme_settings;
CREATE POLICY "anon_insert_programme_settings" ON programme_settings
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_programme_settings" ON programme_settings;
CREATE POLICY "anon_update_programme_settings" ON programme_settings
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- Seed the single settings row if it does not exist yet.
INSERT INTO programme_settings (id, start_date)
VALUES (1, CURRENT_DATE)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS weekly_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  week_number int NOT NULL CHECK (week_number BETWEEN 1 AND 5),
  category text NOT NULL CHECK (category IN ('studying', 'socialising', 'exercising', 'worship')),
  target_hours numeric NOT NULL DEFAULT 0 CHECK (target_hours >= 0),
  created_at timestamptz DEFAULT now(),
  UNIQUE (week_number, category)
);

ALTER TABLE weekly_goals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_weekly_goals" ON weekly_goals;
CREATE POLICY "anon_select_weekly_goals" ON weekly_goals
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_weekly_goals" ON weekly_goals;
CREATE POLICY "anon_insert_weekly_goals" ON weekly_goals
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_weekly_goals" ON weekly_goals;
CREATE POLICY "anon_update_weekly_goals" ON weekly_goals
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_weekly_goals" ON weekly_goals;
CREATE POLICY "anon_delete_weekly_goals" ON weekly_goals
  FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  category text NOT NULL CHECK (category IN ('studying', 'socialising', 'exercising', 'worship')),
  hours numeric NOT NULL CHECK (hours > 0),
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_sessions" ON sessions;
CREATE POLICY "anon_select_sessions" ON sessions
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_sessions" ON sessions;
CREATE POLICY "anon_insert_sessions" ON sessions
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_sessions" ON sessions;
CREATE POLICY "anon_update_sessions" ON sessions
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_sessions" ON sessions;
CREATE POLICY "anon_delete_sessions" ON sessions
  FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_sessions_date ON sessions (date);
CREATE INDEX IF NOT EXISTS idx_sessions_category ON sessions (category);
