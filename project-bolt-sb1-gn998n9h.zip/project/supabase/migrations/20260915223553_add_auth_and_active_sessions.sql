/*
# Add multi-user auth support and active session tracking

1. Modified Tables
- `programme_settings`: add `user_id` column (uuid, references auth.users, default auth.uid()).
  The single-row-per-user model is enforced by a unique constraint on user_id.
  The old single-row CHECK (id = 1) constraint is dropped and replaced.
- `weekly_goals`: add `user_id` column (uuid, references auth.users, default auth.uid()).
  The unique constraint on (week_number, category) is replaced with (user_id, week_number, category).
- `sessions`: add `user_id` column (uuid, references auth.users, default auth.uid()).
  Add `status` column (text, default 'completed') with CHECK constraint for 'completed', 'active', 'paused'.
  Add `started_at` (timestamptz, nullable) — when a live timer session was started.
  Add `paused_at` (timestamptz, nullable) — when the session was last paused.
  Add `elapsed_seconds` (int, default 0) — accumulated seconds from the live timer.

2. New Tables
- `active_timers`
  - Tracks currently running live timer sessions per user.
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, default auth.uid(), references auth.users ON DELETE CASCADE)
  - `category` (text, not null) — one of: studying, socialising, exercising, worship
  - `status` (text, not null, default 'active') — 'active' or 'paused'
  - `started_at` (timestamptz, not null, default now())
  - `paused_at` (timestamptz, nullable)
  - `elapsed_seconds` (int, not null, default 0)
  - `notes` (text, nullable)
  - `created_at` (timestamptz, default now())
  - Unique constraint on user_id (only one active timer per user)

3. Security
- All tables now use `TO authenticated` with `auth.uid() = user_id` ownership checks.
- RLS policies are dropped and recreated for the new multi-user model.
- All owner columns default to `auth.uid()` so inserts omitting user_id succeed.

4. Important Notes
- The old single-tenant seed row in programme_settings (id=1) is deleted since it has no user_id.
- Existing sessions/goals data (if any) is preserved by adding user_id as nullable first,
  then the constraints rely on DEFAULT auth.uid() for new rows.
- The `active_timers` table allows only one timer per user via a unique constraint.
- When a timer is completed, it is converted into a `sessions` row and the active_timer is deleted.
*/

-- programme_settings: add user_id, change constraints
ALTER TABLE programme_settings ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

ALTER TABLE programme_settings DROP CONSTRAINT IF EXISTS programme_settings_single_row;
ALTER TABLE programme_settings DROP CONSTRAINT IF EXISTS programme_settings_user_id_key;
ALTER TABLE programme_settings ADD CONSTRAINT programme_settings_user_id_key UNIQUE (user_id);

-- weekly_goals: add user_id, change unique constraint
ALTER TABLE weekly_goals ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE weekly_goals DROP CONSTRAINT IF EXISTS weekly_goals_week_number_category_key;
ALTER TABLE weekly_goals ADD CONSTRAINT weekly_goals_user_week_cat_key UNIQUE (user_id, week_number, category);

-- sessions: add user_id, status, timer fields
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'completed' CHECK (status IN ('completed', 'active', 'paused'));
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS paused_at timestamptz;
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS elapsed_seconds int NOT NULL DEFAULT 0;

-- Clean up old single-tenant seed row
DELETE FROM programme_settings WHERE user_id IS NULL;

-- New active_timers table
CREATE TABLE IF NOT EXISTS active_timers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  category text NOT NULL CHECK (category IN ('studying', 'socialising', 'exercising', 'worship')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paused')),
  started_at timestamptz NOT NULL DEFAULT now(),
  paused_at timestamptz,
  elapsed_seconds int NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT active_timers_user_id_key UNIQUE (user_id)
);

ALTER TABLE active_timers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_active_timers" ON active_timers;
CREATE POLICY "select_own_active_timers" ON active_timers
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_active_timers" ON active_timers;
CREATE POLICY "insert_own_active_timers" ON active_timers
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_active_timers" ON active_timers;
CREATE POLICY "update_own_active_timers" ON active_timers
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_active_timers" ON active_timers;
CREATE POLICY "delete_own_active_timers" ON active_timers
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Recreate RLS policies for programme_settings (now authenticated-only, owner-scoped)
DROP POLICY IF EXISTS "anon_select_programme_settings" ON programme_settings;
DROP POLICY IF EXISTS "anon_insert_programme_settings" ON programme_settings;
DROP POLICY IF EXISTS "anon_update_programme_settings" ON programme_settings;

DROP POLICY IF EXISTS "select_own_programme_settings" ON programme_settings;
CREATE POLICY "select_own_programme_settings" ON programme_settings
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_programme_settings" ON programme_settings;
CREATE POLICY "insert_own_programme_settings" ON programme_settings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_programme_settings" ON programme_settings;
CREATE POLICY "update_own_programme_settings" ON programme_settings
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Recreate RLS policies for weekly_goals
DROP POLICY IF EXISTS "anon_select_weekly_goals" ON weekly_goals;
DROP POLICY IF EXISTS "anon_insert_weekly_goals" ON weekly_goals;
DROP POLICY IF EXISTS "anon_update_weekly_goals" ON weekly_goals;
DROP POLICY IF EXISTS "anon_delete_weekly_goals" ON weekly_goals;

DROP POLICY IF EXISTS "select_own_weekly_goals" ON weekly_goals;
CREATE POLICY "select_own_weekly_goals" ON weekly_goals
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_weekly_goals" ON weekly_goals;
CREATE POLICY "insert_own_weekly_goals" ON weekly_goals
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_weekly_goals" ON weekly_goals;
CREATE POLICY "update_own_weekly_goals" ON weekly_goals
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_weekly_goals" ON weekly_goals;
CREATE POLICY "delete_own_weekly_goals" ON weekly_goals
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Recreate RLS policies for sessions
DROP POLICY IF EXISTS "anon_select_sessions" ON sessions;
DROP POLICY IF EXISTS "anon_insert_sessions" ON sessions;
DROP POLICY IF EXISTS "anon_update_sessions" ON sessions;
DROP POLICY IF EXISTS "anon_delete_sessions" ON sessions;

DROP POLICY IF EXISTS "select_own_sessions" ON sessions;
CREATE POLICY "select_own_sessions" ON sessions
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_sessions" ON sessions;
CREATE POLICY "insert_own_sessions" ON sessions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_sessions" ON sessions;
CREATE POLICY "update_own_sessions" ON sessions
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_sessions" ON sessions;
CREATE POLICY "delete_own_sessions" ON sessions
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions (user_id);
CREATE INDEX IF NOT EXISTS idx_weekly_goals_user_id ON weekly_goals (user_id);
