/*
# Create per-user programme settings

1. New Tables
- `user_programme_settings`
  - `id` (uuid, primary key)
  - `user_id` (uuid, owner, defaults to auth.uid())
  - `start_date` (date, not null, defaults to today)
  - `updated_at` (timestamptz)
  - one settings row per authenticated user

2. Security
- Enable RLS.
- Add separate authenticated owner policies for SELECT, INSERT, UPDATE, and DELETE.

3. Important Notes
- This table avoids sharing a numeric primary key between different users while preserving the
  original programme_settings table for any existing data.
*/

CREATE TABLE IF NOT EXISTS user_programme_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT user_programme_settings_user_id_key UNIQUE (user_id)
);

ALTER TABLE user_programme_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_user_programme_settings" ON user_programme_settings;
CREATE POLICY "select_own_user_programme_settings" ON user_programme_settings
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_user_programme_settings" ON user_programme_settings;
CREATE POLICY "insert_own_user_programme_settings" ON user_programme_settings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_user_programme_settings" ON user_programme_settings;
CREATE POLICY "update_own_user_programme_settings" ON user_programme_settings
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_user_programme_settings" ON user_programme_settings;
CREATE POLICY "delete_own_user_programme_settings" ON user_programme_settings
  FOR DELETE TO authenticated USING (auth.uid() = user_id);
